import { Product, Review } from '../types';

export const BRAND_LOGO_SRC = '/assets/aistudio/file_0000000096808211afe5fdb0d0dbb7fe_2b7f1a41.png';
export const HERO_EDITORIAL_SRC = '/src/assets/images/hero_fashion_editorial_1794474234186.jpg';

export const SAMPLE_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Matteo Rossini',
    verified: true,
    rating: 5,
    date: '2 weeks ago',
    title: 'Unparalleled Italian Craftsmanship',
    comment: 'The Tuscan full-grain leather smells divine right out of the presentation box. The Goodyear welt construction gives them incredible support, and after just 3 wears they molded like a glove. Nikki World sets the benchmark.',
    location: 'Milan, Italy'
  },
  {
    id: 'rev-2',
    author: 'Alexander Sterling',
    verified: true,
    rating: 5,
    date: '1 month ago',
    title: 'The Perfect Fedora - True Sartorial Statement',
    comment: 'I receive compliments every time I wear this fedora. The wool felt weight is substantial yet breathable, and the golden grosgrain ribbon band matches my Nikki cufflinks impeccably. Fast DHL delivery to Mayfair.',
    location: 'London, UK'
  },
  {
    id: 'rev-3',
    author: 'Julian Vance',
    verified: true,
    rating: 5,
    date: '3 weeks ago',
    title: 'Flawless Suede & Impeccable Fit',
    comment: 'The Chelsea boots have sleek, refined lines that pair seamlessly under both tailored trousers and raw selvedge denim. Very comfortable crepe-cushioned insole.',
    location: 'New York, USA'
  },
  {
    id: 'rev-4',
    author: 'Dominic Dubois',
    verified: true,
    rating: 4,
    date: '1 month ago',
    title: 'Exceptional cut and luxury drape',
    comment: 'The wool blazer fits with that relaxed Florentine shoulder and soft structure that Italian tailors are famed for. Runs true to size with room for light layering.',
    location: 'Paris, France'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'nw-oxford-cognac',
    name: 'The Sovereign Oxford Brogues',
    subtitle: 'Hand-burnished Tuscan Cognac Calfskin',
    category: 'Footwear',
    gender: 'Men',
    price: 340,
    originalPrice: 425,
    rating: 4.9,
    reviewsCount: 184,
    images: [
      '/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg',
      '/src/assets/images/product_chelsea_boot_1794474235777.jpg',
      '/src/assets/images/hero_fashion_editorial_1794474234186.jpg'
    ],
    colors: [
      { name: 'Tuscan Cognac', hex: '#8B4513', inStock: true },
      { name: 'Obsidian Noir', hex: '#1A1A1A', inStock: true },
      { name: 'Rich Espresso', hex: '#3B2219', inStock: true }
    ],
    sizes: [
      { size: 'US 8 / EU 41', stock: 'in_stock' },
      { size: 'US 8.5 / EU 42', stock: 'in_stock' },
      { size: 'US 9 / EU 42.5', stock: 'low_stock' },
      { size: 'US 9.5 / EU 43', stock: 'in_stock' },
      { size: 'US 10 / EU 44', stock: 'in_stock' },
      { size: 'US 10.5 / EU 44.5', stock: 'low_stock' },
      { size: 'US 11 / EU 45', stock: 'out_of_stock' }
    ],
    badge: 'BESTSELLER',
    isTrending: true,
    isBestseller: true,
    description: 'The pinnacle of classical European shoemaking. Each Sovereign Oxford is hand-lasted in Tuscany from full-grain calfskin with meticulous brogue perforation patterns. Hand-burnished by master cordwainers to achieve a warm, depth-rich patina that matures beautifully over decades.',
    features: [
      'Genuine Goodyear 360 welted sole for lifetime resoleability',
      'Artisanal hand-burnished vegetable-tanned French calfskin',
      'Cork-filled midsole molds organically to the contour of your foot',
      'Beveled leather waist with protective brass toe taps',
      'Presented in a lacquered wooden Nikki World collector box'
    ],
    specs: {
      craftsmanship: 'Handcrafted in Santa Croce sull\'Arno, Italy. 160 manual steps per pair.',
      materials: '100% full-grain European calfskin upper, vegetal calf lining, stacked oak-bark leather heel.',
      fitRecommendation: 'Runs true to traditional Italian dress shoe sizing. If between sizes, choose your normal dress shoe size.',
      shipping: 'Complimentary Worldwide DHL Express shipping with signature confirmation and 30-day bespoke returns.'
    },
    sku: 'NW-FW-1049-COG'
  },
  {
    id: 'nw-monarch-fedora',
    name: 'The Monarch Wool Felt Fedora',
    subtitle: 'Hand-molded Australian Merino with Golden Trim',
    category: 'Hats',
    gender: 'Unisex',
    price: 185,
    originalPrice: 220,
    rating: 4.95,
    reviewsCount: 142,
    images: [
      '/src/assets/images/product_fedora_hat_1794474234880.jpg',
      '/src/assets/images/hero_fashion_editorial_1794474234186.jpg'
    ],
    colors: [
      { name: 'Charcoal with Gold', hex: '#4A4A4A', inStock: true },
      { name: 'Obsidian Noir', hex: '#1C1C1C', inStock: true },
      { name: 'Warm Camel', hex: '#C19A6B', inStock: true }
    ],
    sizes: [
      { size: 'S (55-56 cm)', stock: 'in_stock' },
      { size: 'M (57-58 cm)', stock: 'in_stock' },
      { size: 'L (59-60 cm)', stock: 'in_stock' },
      { size: 'XL (61-62 cm)', stock: 'low_stock' }
    ],
    badge: 'ARTISANAL',
    isTrending: true,
    isBestseller: true,
    description: 'Inspired by the signature gentleman emblem in our brand mark. The Monarch Fedora is steam-shaped from dense 100% Australian Merino wool felt, accented with Nikki World signature golden-yellow grosgrain ribbon and a hand-turned bound brim edge.',
    features: [
      'Dense 140g/m² water-repellent Merino wool felt body',
      'Signature Golden Yellow grosgrain ribbon trim with bespoke side bow',
      'Natural moisture-wicking calfskin sweatband inside',
      'Reinforced teardrop crown maintains crisp shape through travel',
      'Embossed with the Nikki World golden gentleman insignia'
    ],
    specs: {
      craftsmanship: 'Hand-blocked in Florence using 19th-century wooden hat molds.',
      materials: '100% Australian Merino Wool Felt, Silk lining, Italian Grosgrain Ribbon.',
      fitRecommendation: 'Measure around your head 1 cm above your ears. If in between measurements, select the larger size.',
      shipping: 'Ships in an architectural reinforced hat box designed to preserve crown and brim integrity.'
    },
    sku: 'NW-HT-2088-GLD'
  },
  {
    id: 'nw-chelsea-suede',
    name: 'Tuscan Amber Suede Chelsea Boot',
    subtitle: 'Water-resistant Velour Suede with Crepe Trim',
    category: 'Footwear',
    gender: 'Men',
    price: 310,
    originalPrice: 380,
    rating: 4.88,
    reviewsCount: 96,
    images: [
      '/src/assets/images/product_chelsea_boot_1794474235777.jpg',
      '/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg'
    ],
    colors: [
      { name: 'Chestnut Amber', hex: '#8C4824', inStock: true },
      { name: 'Sand Taupe', hex: '#C2B29D', inStock: true },
      { name: 'Midnight Charcoal', hex: '#262626', inStock: true }
    ],
    sizes: [
      { size: 'US 8 / EU 41', stock: 'in_stock' },
      { size: 'US 8.5 / EU 42', stock: 'in_stock' },
      { size: 'US 9 / EU 42.5', stock: 'in_stock' },
      { size: 'US 9.5 / EU 43', stock: 'low_stock' },
      { size: 'US 10 / EU 44', stock: 'in_stock' },
      { size: 'US 10.5 / EU 44.5', stock: 'in_stock' },
      { size: 'US 11 / EU 45', stock: 'in_stock' }
    ],
    badge: 'NEW SEASON',
    isTrending: true,
    isBestseller: false,
    description: 'Effortless versatility redefined. Crafted from supple Italian reverse calf suede treated with a nanotech water-resistant barrier. Designed with elasticated side gussets and reinforced rear pull tabs for seamless slip-on comfort and refined drape.',
    features: [
      'Silky Italian velour suede treated for rain and spot resistance',
      'Durable Goodyear welt with storm welt perimeter',
      'Dual woven pull tabs engineered for effortless entry',
      'Ergonomic memory-cushion leather insole for all-day comfort',
      'Vibram low-profile studded rubber sole for dependable all-weather grip'
    ],
    specs: {
      craftsmanship: 'Produced in small batches by master cordwainers in Civitanova Marche, Italy.',
      materials: 'Water-resistant reverse calf suede, glove-soft leather lining, custom Vibram outsole.',
      fitRecommendation: 'Snug fit across the instep initially; will relax to your foot shape after 24 hours of wear.',
      shipping: 'Complimentary DHL Express worldwide delivery with signature delivery.'
    },
    sku: 'NW-FW-3301-SUED'
  },
  {
    id: 'nw-blazer-charcoal',
    name: 'Sartorial Charcoal Wool Blazer',
    subtitle: 'Vitale Barberis Canonico Super 130s Wool',
    category: 'Tailoring',
    gender: 'Men',
    price: 490,
    originalPrice: 590,
    rating: 4.92,
    reviewsCount: 78,
    images: [
      '/src/assets/images/product_bespoke_suit_1794474235301.jpg',
      '/src/assets/images/hero_fashion_editorial_1794474234186.jpg'
    ],
    colors: [
      { name: 'Charcoal Melange', hex: '#3E424B', inStock: true },
      { name: 'Florentine Navy', hex: '#1B263B', inStock: true },
      { name: 'Tuscan Olive', hex: '#4B5320', inStock: false }
    ],
    sizes: [
      { size: '38R (IT 48)', stock: 'in_stock' },
      { size: '40R (IT 50)', stock: 'in_stock' },
      { size: '42R (IT 52)', stock: 'low_stock' },
      { size: '44R (IT 54)', stock: 'in_stock' },
      { size: '46R (IT 56)', stock: 'low_stock' }
    ],
    badge: 'LIMITED RUN',
    isTrending: false,
    isBestseller: true,
    description: 'A benchmark in modern Neapolitan tailoring. Unstructured shoulders (spalla camicia), half-canvas construction, and patch pockets give this blazer an effortlessly elegant silhouette suitable for high-stakes boardrooms or casual twilight aperitivos.',
    features: [
      'Woven from Vitale Barberis Canonico Super 130s Italian wool',
      'Spalla camicia soft unpadded shoulders for natural masculine drape',
      'Natural horn buttons custom cast with Nikki World insignia',
      'Pick-stitching (punto a mano) along notch lapels and flap edges',
      'Double rear vents and breathable Cupro Bemberg silk lining'
    ],
    specs: {
      craftsmanship: 'Cut and sewn in Naples, Italy with over 45 hours of individual tailoring.',
      materials: '100% Super 130s Pure Wool, 100% Cupro lining, authentic Buffalo horn buttons.',
      fitRecommendation: 'Modern tailored fit. Fits cleanly across shoulders without pulling.',
      shipping: 'Delivered in a bespoke breathable cedar-scented canvas garment travel bag.'
    },
    sku: 'NW-TL-4012-CHR'
  },
  {
    id: 'nw-overcoat-camel',
    name: 'Firenze Cashmere Wrap Overcoat',
    subtitle: 'Double-Faced Loro Piana Wool & Cashmere',
    category: 'Women',
    gender: 'Women',
    price: 680,
    originalPrice: 850,
    rating: 4.97,
    reviewsCount: 63,
    images: [
      '/src/assets/images/hero_fashion_editorial_1794474234186.jpg',
      '/src/assets/images/product_bespoke_suit_1794474235301.jpg'
    ],
    colors: [
      { name: 'Warm Camel', hex: '#C69D67', inStock: true },
      { name: 'Oatmeal Melange', hex: '#DFD7C7', inStock: true },
      { name: 'Jet Noir', hex: '#141414', inStock: true }
    ],
    sizes: [
      { size: 'US 2 / IT 38', stock: 'in_stock' },
      { size: 'US 4 / IT 40', stock: 'in_stock' },
      { size: 'US 6 / IT 42', stock: 'in_stock' },
      { size: 'US 8 / IT 44', stock: 'low_stock' },
      { size: 'US 10 / IT 46', stock: 'low_stock' }
    ],
    badge: 'NEW SEASON',
    isTrending: true,
    isBestseller: true,
    description: 'An architectural outerwear triumph. Sumptuously soft double-faced Italian wool blended with Mongolian cashmere. Features generous notched lapels, deep welt pockets, and a detachable self-fabric tie belt for defined cinching.',
    features: [
      '90% Virgin Italian Wool, 10% Grade-A Mongolian Cashmere',
      'Hand-finished blind seams throughout for an unlined, featherlight feel',
      'Removable belt with topstitch detailing',
      'Graceful midi length designed to float over tailoring or dresses',
      'Deep thermal comfort down to -5°C (23°F)'
    ],
    specs: {
      craftsmanship: 'Hand-sewn by female master seamstresses in Biella, Northern Italy.',
      materials: 'Double-faced virgin wool & cashmere yarn, mother-of-pearl interior stay buttons.',
      fitRecommendation: 'Relaxed tailored drape. Designed to comfortably accommodate light knitwear underneath.',
      shipping: 'Arrives in padded archival garment travel bag with wide wooden hanger.'
    },
    sku: 'NW-WM-5009-CML'
  },
  {
    id: 'nw-double-monk',
    name: 'Verona Double-Monk Strap Shoes',
    subtitle: 'Antiqued Calfskin with Hand-Polished Brass Buckles',
    category: 'Footwear',
    gender: 'Men',
    price: 360,
    originalPrice: 420,
    rating: 4.89,
    reviewsCount: 112,
    images: [
      '/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg',
      '/src/assets/images/product_chelsea_boot_1794474235777.jpg'
    ],
    colors: [
      { name: 'Deep Espresso', hex: '#3B2219', inStock: true },
      { name: 'Tuscan Tan', hex: '#8B4513', inStock: true },
      { name: 'Black Onyx', hex: '#1C1C1C', inStock: true }
    ],
    sizes: [
      { size: 'US 8 / EU 41', stock: 'in_stock' },
      { size: 'US 8.5 / EU 42', stock: 'in_stock' },
      { size: 'US 9 / EU 42.5', stock: 'in_stock' },
      { size: 'US 9.5 / EU 43', stock: 'in_stock' },
      { size: 'US 10 / EU 44', stock: 'low_stock' },
      { size: 'US 11 / EU 45', stock: 'low_stock' }
    ],
    badge: 'BESTSELLER',
    isTrending: false,
    isBestseller: true,
    description: 'A striking statement of refined audacity. The Verona double-monk features dual buckle straps sculpted from solid antiqued brass, sitting atop an elongated chiseled toe box with hand-applied mirror glazing on the cap.',
    features: [
      'Dual adjustable solid brass buckle fasteners with hidden elastic',
      'Blake-Rapid stitched construction offering slim silhouette with durability',
      'Channel-stitched sole with hand-painted burgundy fiddleback waist',
      'Pre-conditioned with Nikki World beeswax leather balm',
      'Full leather heel with brass nail accents'
    ],
    specs: {
      craftsmanship: 'Produced in Civitanova Marche, Italy.',
      materials: '100% French Box Calf leather, brass hardware, vegetable-tanned sole leather.',
      fitRecommendation: 'True to standard European dress sizes. Adjustable straps accommodate high or low arches.',
      shipping: 'Complimentary DHL Express worldwide delivery.'
    },
    sku: 'NW-FW-6110-ESP'
  },
  {
    id: 'nw-leather-belt',
    name: 'Artisan Calfskin Dress Belt',
    subtitle: 'Full-Grain Tuscan Bridle Leather & Brushed Brass',
    category: 'Accessories',
    gender: 'Unisex',
    price: 110,
    originalPrice: 135,
    rating: 4.93,
    reviewsCount: 88,
    images: [
      '/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg',
      '/src/assets/images/product_bespoke_suit_1794474235301.jpg'
    ],
    colors: [
      { name: 'Cognac Amber', hex: '#8B4513', inStock: true },
      { name: 'Obsidian Noir', hex: '#171717', inStock: true },
      { name: 'Espresso', hex: '#3B2219', inStock: true }
    ],
    sizes: [
      { size: '32 in (80 cm)', stock: 'in_stock' },
      { size: '34 in (85 cm)', stock: 'in_stock' },
      { size: '36 in (90 cm)', stock: 'in_stock' },
      { size: '38 in (95 cm)', stock: 'in_stock' },
      { size: '40 in (100 cm)', stock: 'low_stock' }
    ],
    badge: 'ARTISANAL',
    isTrending: false,
    isBestseller: false,
    description: 'The definitive finishing touch. Hand-cut 32mm width strap matching our Sovereign Oxfords and Chelsea boots. Beveled and burnished by hand using organic tree sap wax, paired with a solid brass buckle with satin finish.',
    features: [
      'Cut from heavy 4.0mm thick vegetable-tanned bridle leather',
      'Solid forged brass hardware with hypoallergenic satin nickel coating',
      'Five hand-punched tear-drop holes with debossed size indicators',
      'Discreet Nikki World gentleman emblem on interior tip',
      'Will develop a personal honeyed patina over years of use'
    ],
    specs: {
      craftsmanship: 'Handcrafted in Florence, Italy.',
      materials: 'Full-grain vegetable-tanned bovine bridle leather, solid brass buckle.',
      fitRecommendation: 'Order 2 inches larger than your trousers waist measurement (e.g., if you wear 32 waist pants, choose 34 belt).',
      shipping: 'Ships in gift-ready textured presentation pouch.'
    },
    sku: 'NW-AC-7021-BLT'
  },
  {
    id: 'nw-driving-loafer',
    name: 'Palermo Suede Driving Loafers',
    subtitle: 'Ultra-Flex Pebble Rubber Sole in Tuscan Suede',
    category: 'Footwear',
    gender: 'Men',
    price: 260,
    originalPrice: 320,
    rating: 4.86,
    reviewsCount: 74,
    images: [
      '/src/assets/images/product_chelsea_boot_1794474235777.jpg',
      '/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg'
    ],
    colors: [
      { name: 'Mediterranean Navy', hex: '#1C2841', inStock: true },
      { name: 'Tuscan Suede Amber', hex: '#9E5B32', inStock: true },
      { name: 'Olive Drab', hex: '#4B5320', inStock: true }
    ],
    sizes: [
      { size: 'US 8 / EU 41', stock: 'in_stock' },
      { size: 'US 8.5 / EU 42', stock: 'in_stock' },
      { size: 'US 9 / EU 42.5', stock: 'in_stock' },
      { size: 'US 9.5 / EU 43', stock: 'in_stock' },
      { size: 'US 10 / EU 44', stock: 'low_stock' },
      { size: 'US 11 / EU 45', stock: 'in_stock' }
    ],
    badge: '20% OFF',
    isTrending: true,
    isBestseller: false,
    description: 'Designed for coastal escapism and weekend journeys. Unlined, buttery soft Italian calfskin suede with tubular moccasin construction and individual rubber pebble studs that wrap around the heel for superior pedal control.',
    features: [
      'Featherlight tubular moccasin construction molds instantly',
      'Individual molded rubber driving pebbles for maximum flex',
      'Hand-stitched vamp apron by artisan cordwainers',
      'Perforated calfskin footbed for barefoot summer wear',
      'Reinforced heel wrap resists wear during driving'
    ],
    specs: {
      craftsmanship: 'Hand-sewn in Montegranaro, Italy.',
      materials: '100% Italian reverse suede, rubber gommini studs.',
      fitRecommendation: 'True to size. Designed to be worn with or without no-show socks.',
      shipping: 'Complimentary DHL Express worldwide shipping.'
    },
    sku: 'NW-FW-8092-DRV'
  }
];
