import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { BRAND_LOGO_SRC, SAMPLE_REVIEWS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import {
  ArrowRight,
  Copy,
  Check,
  Sparkles,
  Star,
  ShieldCheck,
  ChevronRight,
  ChevronUp,
  Lock,
  Play
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const {
    products,
    heroConfig,
    navigateTo,
    applyCoupon,
    showToast,
    setIsAdminModalOpen,
    isOwnerAuthenticated
  } = useShop();

  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<'All' | 'Footwear' | 'Hats' | 'Tailoring'>('All');

  const trendingProducts = products.filter((p) => p.isTrending);
  const bestsellerProducts = products.filter((p) => p.isBestseller);

  const filteredBestsellers = selectedCategoryTab === 'All'
    ? bestsellerProducts
    : bestsellerProducts.filter((p) => p.category === selectedCategoryTab);

  const handleCopyCode = () => {
    navigator.clipboard?.writeText('NIKKISTYLE');
    applyCoupon('NIKKISTYLE');
    setCopiedCode(true);
    showToast('Promo code NIKKISTYLE copied and applied!');
    setTimeout(() => setCopiedCode(false), 3000);
  };

  return (
    <div className="space-y-12 sm:space-y-16 pb-16 overflow-x-hidden">
      
      {/* 1. HERO EDITORIAL BANNER (SUPPORTS DYNAMIC IMAGE OR VIDEO REEL) */}
      <section className="relative overflow-hidden bg-stone-950 text-white">
        
        {/* Background Video or Image */}
        {heroConfig.mediaType === 'video' && heroConfig.videoUrl ? (
          <div className="absolute inset-0 z-0 opacity-35 overflow-hidden">
            <video
              autoPlay
              muted
              loop
              playsInline
              className="w-full h-full object-cover"
            >
              <source src={heroConfig.videoUrl} type="video/mp4" />
            </video>
            <div className="absolute inset-0 bg-stone-950/70" />
          </div>
        ) : (
          <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
            <img
              src={heroConfig.mediaUrl}
              alt="Editorial Backdrop"
              className="w-full h-full object-cover blur-xs"
            />
          </div>
        )}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 lg:py-28 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-5 sm:space-y-6 text-center sm:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-stone-200 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#F5B301]" />
              <span>{heroConfig.badgeText}</span>
              {heroConfig.mediaType === 'video' && (
                <span className="flex items-center gap-1 text-[10px] text-[#F5B301] uppercase font-bold ml-1">
                  <Play className="w-2.5 h-2.5 fill-current" /> Live Reel
                </span>
              )}
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-display leading-[1.1] text-white">
              {heroConfig.headline}
            </h1>

            <p className="text-sm sm:text-lg text-stone-300 max-w-xl font-light leading-relaxed mx-auto sm:mx-0">
              {heroConfig.subheadline}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 sm:gap-4 pt-2">
              <button
                onClick={() => navigateTo('shop')}
                className="w-full sm:w-auto px-8 py-3.5 sm:py-4 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs sm:text-sm tracking-wide uppercase rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <button
                onClick={() => navigateTo('about')}
                className="w-full sm:w-auto px-7 py-3.5 sm:py-4 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 backdrop-blur-sm transition-colors cursor-pointer"
              >
                Atelier Heritage
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="pt-4 sm:pt-6 border-t border-white/10 grid grid-cols-3 gap-4 sm:gap-6 max-w-md mx-auto sm:mx-0 text-center sm:text-left">
              <div>
                <span className="block text-xl sm:text-2xl font-bold text-white tabular-nums font-display">160+</span>
                <span className="text-[11px] sm:text-xs text-stone-400">Hand-finished steps</span>
              </div>
              <div>
                <span className="block text-xl sm:text-2xl font-bold text-white tabular-nums font-display">100%</span>
                <span className="text-[11px] sm:text-xs text-stone-400">Tuscan full-grain</span>
              </div>
              <div>
                <span className="block text-xl sm:text-2xl font-bold text-[#F5B301] tabular-nums font-display">4.9★</span>
                <span className="text-[11px] sm:text-xs text-stone-400">Client satisfaction</span>
              </div>
            </div>
          </div>

          {/* Right Showcase Card */}
          <div className="lg:col-span-5 relative mt-4 lg:mt-0">
            <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-2xl group bg-stone-900 aspect-[4/5] max-w-md mx-auto">
              <img
                src={heroConfig.mediaUrl}
                alt="Nikki World Showcase"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Overlay Glass Card */}
              <div className="absolute inset-x-3 sm:inset-x-4 bottom-3 sm:bottom-4 p-3.5 sm:p-4 rounded-xl bg-stone-950/85 backdrop-blur-md border border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-[#F5B301] font-bold tracking-wider uppercase block">
                    Signature Atelier Drop
                  </span>
                  <h4 className="text-xs sm:text-sm font-bold text-white font-display">
                    The Sovereign & Monarch Series
                  </h4>
                  <span className="text-[11px] text-stone-400">Hand-lasted in Santa Croce sull'Arno</span>
                </div>
                <button
                  onClick={() => navigateTo('shop')}
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#F5B301] text-stone-950 flex items-center justify-center hover:bg-white transition-colors shrink-0"
                >
                  <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Ambient Warm Glow */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#F5B301]/10 rounded-full blur-3xl pointer-events-none" />
      </section>


      {/* 2. CATEGORY SELECTOR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 sm:mb-8 pb-4 border-b border-stone-200 gap-2">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block mb-1">
              Curated Sartorial Categories
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
              Excellence in Every Silhouette
            </h2>
          </div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs font-bold uppercase tracking-wider text-stone-800 hover:text-[#B3541E] flex items-center gap-1 transition-colors self-start md:self-auto"
          >
            <span>View All Collections</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Category Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
          <div
            onClick={() => navigateTo('shop')}
            className="group relative rounded-xl overflow-hidden aspect-[3/4] bg-stone-900 cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <img
              src="/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg"
              alt="Footwear Collection"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent flex flex-col justify-end p-3 sm:p-5">
              <span className="text-[10px] text-[#F5B301] font-bold tracking-wider uppercase">Handcrafted</span>
              <h3 className="text-sm sm:text-lg font-bold text-white font-display">Footwear</h3>
              <p className="text-[11px] text-stone-300 mt-0.5 hidden sm:block">
                Goodyear Welted Brogues & Chelsea Boots
              </p>
            </div>
          </div>

          <div
            onClick={() => navigateTo('shop')}
            className="group relative rounded-xl overflow-hidden aspect-[3/4] bg-stone-900 cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <img
              src="/src/assets/images/product_fedora_hat_1794474234880.jpg"
              alt="Fedoras & Hats Collection"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent flex flex-col justify-end p-3 sm:p-5">
              <span className="text-[10px] text-[#F5B301] font-bold tracking-wider uppercase">Iconic House</span>
              <h3 className="text-sm sm:text-lg font-bold text-white font-display">Fedoras & Hats</h3>
              <p className="text-[11px] text-stone-300 mt-0.5 hidden sm:block">
                Merino Wool Felt & Golden Ribbon
              </p>
            </div>
          </div>

          <div
            onClick={() => navigateTo('shop')}
            className="group relative rounded-xl overflow-hidden aspect-[3/4] bg-stone-900 cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <img
              src="/src/assets/images/product_bespoke_suit_1794474235301.jpg"
              alt="Bespoke Tailoring"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent flex flex-col justify-end p-3 sm:p-5">
              <span className="text-[10px] text-[#F5B301] font-bold tracking-wider uppercase">Sartorial Cut</span>
              <h3 className="text-sm sm:text-lg font-bold text-white font-display">Bespoke Tailoring</h3>
              <p className="text-[11px] text-stone-300 mt-0.5 hidden sm:block">
                Super 130s Wool Blazers & Trousers
              </p>
            </div>
          </div>

          <div
            onClick={() => navigateTo('shop')}
            className="group relative rounded-xl overflow-hidden aspect-[3/4] bg-stone-900 cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <img
              src="/src/assets/images/hero_fashion_editorial_1794474234186.jpg"
              alt="Women & Cashmere Outerwear"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent flex flex-col justify-end p-3 sm:p-5">
              <span className="text-[10px] text-[#F5B301] font-bold tracking-wider uppercase">Double-Faced</span>
              <h3 className="text-sm sm:text-lg font-bold text-white font-display">Outerwear</h3>
              <p className="text-[11px] text-stone-300 mt-0.5 hidden sm:block">
                Cashmere Wrap Coats & Silk Stoles
              </p>
            </div>
          </div>
        </div>
      </section>


      {/* 3. TRENDING DROPS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#F5B301]" />
              <span className="text-xs uppercase tracking-widest text-stone-500 font-bold">
                Seasonal Releases
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display mt-1">
              Trending Drops
            </h2>
          </div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs font-bold uppercase tracking-wider text-stone-800 hover:text-[#B3541E] transition-colors"
          >
            See All ({products.length})
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {trendingProducts.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>


      {/* 4. PROMOTIONAL OFFER BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-stone-950 via-[#221711] to-stone-950 text-white p-6 sm:p-12 border border-amber-900/40 shadow-xl">
          <div className="relative z-10 max-w-2xl space-y-4">
            <span className="inline-block px-3 py-1 rounded bg-[#F5B301] text-stone-950 text-xs font-bold tracking-wider uppercase">
              Exclusive Seasonal Promotion
            </span>
            <h3 className="text-2xl sm:text-4xl font-extrabold font-display leading-tight text-white">
              {heroConfig.promoBannerText}
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              Step into unparalleled Italian comfort. Enjoy 20% off all Oxford brogues, suede Chelsea boots, and driving loafers using our seasonal code at checkout.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
              <div className="flex items-center bg-stone-900/90 border border-[#F5B301]/50 rounded-lg px-3.5 py-2">
                <span className="text-xs text-stone-400 mr-2 uppercase tracking-wider font-semibold">Code:</span>
                <span className="text-sm sm:text-base font-extrabold text-[#F5B301] tracking-wider font-mono">
                  NIKKISTYLE
                </span>
                <button
                  onClick={handleCopyCode}
                  className="ml-3 p-1.5 text-stone-300 hover:text-white rounded bg-stone-800 transition-colors cursor-pointer"
                  title="Copy code"
                >
                  {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <button
                onClick={() => navigateTo('shop')}
                className="px-5 py-2.5 sm:px-6 sm:py-3 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
              >
                Claim Offer in Shop
              </button>
            </div>
          </div>
        </div>
      </section>


      {/* 5. CURATED BESTSELLERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 sm:mb-8 pb-4 border-b border-stone-200 gap-4">
          <div>
            <span className="text-xs uppercase tracking-widest text-stone-500 font-bold block mb-1">
              The Permanent Collection
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
              Curated Bestsellers
            </h2>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-stone-200/60 rounded-lg overflow-x-auto scrollbar-none">
            {(['All', 'Footwear', 'Hats', 'Tailoring'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setSelectedCategoryTab(tab)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer whitespace-nowrap ${
                  selectedCategoryTab === tab
                    ? 'bg-white text-stone-950 shadow-xs'
                    : 'text-stone-600 hover:text-stone-950'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredBestsellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>


      {/* 6. CRAFTSMANSHIP SPOTLIGHT */}
      <section className="bg-white border-y border-stone-200 py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-square bg-stone-900 border border-stone-200 max-w-md mx-auto">
              <img
                src={BRAND_LOGO_SRC}
                alt="Nikki World Signage"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:col-span-7 space-y-4 sm:space-y-6">
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block">
              The Gentleman Standard
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-stone-950 font-display">
              Where Tuscan Tannery Art Meets Bespoke Millinery
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Every Nikki World creation begins with the finest materials known to European tailoring. From the storied tanneries of Santa Croce sull'Arno to our Florentine hat-makers who steam-shape Australian Merino felt over century-old wooden lasts.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 pt-2">
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200/80">
                <span className="font-bold text-stone-900 text-xs sm:text-sm block">Goodyear 360° Welting</span>
                <p className="text-[11px] sm:text-xs text-stone-500 mt-1">
                  Engineered to be resoled repeatedly, guaranteeing your footwear endures for decades of confident stride.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200/80">
                <span className="font-bold text-stone-900 text-xs sm:text-sm block">Natural Patina Maturation</span>
                <p className="text-[11px] sm:text-xs text-stone-500 mt-1">
                  Vegetable tannins derived from chestnut and mimosa barks ensure leather deepens with rich character.
                </p>
              </div>
            </div>

            <div>
              <button
                onClick={() => navigateTo('about')}
                className="px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer inline-flex items-center gap-2"
              >
                <span>Read The Brand Story</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>
      </section>


      {/* 7. CUSTOMER REVIEWS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-8 sm:mb-10">
          <span className="text-xs uppercase tracking-widest text-stone-500 font-bold block mb-1">
            Connoisseur Acclaim
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
            Endorsed by Discerning Patrons
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          {SAMPLE_REVIEWS.slice(0, 3).map((review) => (
            <div
              key={review.id}
              className="p-5 sm:p-6 bg-white rounded-xl border border-stone-200/80 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 text-[#F5B301] mb-2 sm:mb-3">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <h4 className="text-xs sm:text-sm font-bold text-stone-900 mb-1.5 sm:mb-2">
                  "{review.title}"
                </h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  {review.comment}
                </p>
              </div>

              <div className="mt-4 sm:mt-6 pt-3 sm:pt-4 border-t border-stone-100 flex items-center justify-between text-xs">
                <div>
                  <strong className="text-stone-900 block font-semibold">{review.author}</strong>
                  <span className="text-stone-400 text-[11px]">{review.location}</span>
                </div>
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Verified Buyer
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>


      {/* ========================================================================= */}
      {/* 8. REQUESTED OWNER / ADMIN PORTAL AT THE BOTTOM-MOST OF HOME PAGE (UPWARD ARROW) */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-stone-950 via-[#1C1612] to-stone-950 text-white p-6 sm:p-8 border-2 border-[#F5B301]/50 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center gap-4 text-center sm:text-left">
            {/* The Prominent Upward Arrow Button Trigger */}
            <button
              onClick={() => setIsAdminModalOpen(true)}
              className="w-14 h-14 rounded-2xl bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 flex flex-col items-center justify-center shadow-lg transition-transform hover:-translate-y-1 cursor-pointer shrink-0 group"
              aria-label="Open Owner Portal"
              title="Open Executive Portal"
            >
              <ChevronUp className="w-7 h-7 stroke-[3] group-hover:scale-110 transition-transform" />
              <span className="text-[9px] font-black uppercase tracking-tighter -mt-1">PORTAL</span>
            </button>

            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#F5B301]">
                  Executive Control Suite
                </span>
                <span className="px-2 py-0.5 rounded bg-white/10 text-stone-300 text-[10px] font-mono">
                  Authorized Access
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-white font-display mt-0.5">
                Owner & Administration Portal
              </h3>
              <p className="text-xs text-stone-400 mt-0.5 max-w-xl">
                Orders with printable bills & slips, inventory catalogue with live sync & photo upload, customer management, staff, DHL shipments, returns, discounts, and home screen video/image controls.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setIsAdminModalOpen(true)}
              className="px-6 py-3 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isOwnerAuthenticated ? 'Enter Portal Dashboard' : 'Owner Login'}</span>
              <ChevronUp className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

        </div>
      </section>

    </div>
  );
};
