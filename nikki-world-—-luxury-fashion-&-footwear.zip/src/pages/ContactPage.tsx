import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { MessageSquare, Phone, Mail, Clock, Check, ChevronDown, ChevronUp, ShieldCheck } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { showToast } = useShop();

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    topic: 'Sizing & Fit Advisory',
    orderNumber: '',
    message: ''
  });

  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setFormSubmitted(true);
      showToast('Inquiry received. Our VIP Concierge will respond within 4 business hours.');
    }
  };

  const faqs = [
    {
      q: 'How does Nikki World footwear fit compared to standard athletic shoes?',
      a: 'Our shoes are crafted on traditional Italian dress lasts (Santa Croce standards). They generally fit true to formal European sizing. If you wear a US 10 in sneakers, you will most likely take a US 9.5 or EU 43 in our Oxford brogues and Chelsea boots. Check our Size Guide on any product page.'
    },
    {
      q: 'Can Nikki World shoes be resoled in the future?',
      a: 'Yes, absolutely. All of our dress shoes and Chelsea boots are constructed with genuine 360° Goodyear welts or Blake-Rapid stitching. This allows our Florence cobblers or any competent master cordwainer to replace the outer sole repeatedly without affecting the upper.'
    },
    {
      q: 'What is your complimentary global delivery policy?',
      a: 'We provide complimentary DHL Express Worldwide shipping on all orders over $250. Orders are processed from our Tuscan distribution center within 24 hours, packaged in cedar-scented presentation boxes with tracking and signature delivery.'
    },
    {
      q: 'How do I care for my wool felt fedora during travel?',
      a: 'Our Monarch Fedoras are water-repellent and resilient. For travel, pack light soft garments inside the crown and rest the hat upright in your luggage, or use our reinforced Nikki World architectural hat carrier.'
    },
    {
      q: 'What is the procedure for bespoke returns and exchanges?',
      a: 'Every order arrives with a prepaid DHL return label and return documentation. You have 30 days from delivery to request a complimentary size exchange or full refund, provided items are unworn on carpeted surfaces.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      
      {/* 1. Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block">
          Client Care & Private Advisory
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-stone-950 font-display">
          Nikki World Concierge
        </h1>
        <p className="text-xs sm:text-sm text-stone-600">
          Whether you need personalized sizing advice, custom leather guidance, or private fitting appointments at our flagship boutique in Sardarpura, Jodhpur, our concierge team is at your service.
        </p>
      </div>

      {/* 2. Direct Contact Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-[#B3541E] flex items-center justify-center">
            <MessageSquare className="w-6 h-6" />
          </div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">WhatsApp Concierge</h3>
          <p className="text-xs text-stone-500">Real-time fit advice & video consultations.</p>
          <span className="text-xs font-bold text-stone-950 pt-1">+91 291 261 4432</span>
        </div>

        <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-[#B3541E] flex items-center justify-center">
            <Phone className="w-6 h-6" />
          </div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">Jodhpur Flagship Line</h3>
          <p className="text-xs text-stone-500">Sardarpura Boutique Desk.</p>
          <span className="text-xs font-bold text-stone-950 pt-1">+91 98290 14432</span>
        </div>

        <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-[#B3541E] flex items-center justify-center">
            <Mail className="w-6 h-6" />
          </div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">Direct Email</h3>
          <p className="text-xs text-stone-500">Response guaranteed in 4 business hours.</p>
          <span className="text-xs font-bold text-stone-950 pt-1">concierge@nikkiworld.com</span>
        </div>

        <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-[#B3541E] flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">Boutique Hours</h3>
          <p className="text-xs text-stone-500">Sardarpura, Jodhpur (IST).</p>
          <span className="text-xs font-bold text-stone-950 pt-1">10:30 - 21:00 IST Daily</span>
        </div>
      </div>

      {/* 3. Concierge Inquiry Form & Atelier Visit Scheduling */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Form Container */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-sm">
          <h2 className="text-xl font-bold text-stone-950 font-display mb-1">
            Send a Private Dispatch
          </h2>
          <p className="text-xs text-stone-500 mb-6">
            Fill in your details below and our personal styling desk will respond promptly.
          </p>

          {formSubmitted ? (
            <div className="p-8 rounded-xl bg-emerald-50 border border-emerald-200 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <Check className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900">Dispatch Received</h3>
              <p className="text-xs text-stone-600 max-w-sm mx-auto">
                Thank you, <strong>{formData.name}</strong>. A dedicated concierge has been assigned to ticket #NW-CON-{Math.floor(1000 + Math.random() * 9000)}.
              </p>
              <button
                onClick={() => setFormSubmitted(false)}
                className="mt-4 px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold"
              >
                Send Another Dispatch
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lord Julian Vance"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="julian.vance@domain.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Topic / Inquiry Category</label>
                  <select
                    value={formData.topic}
                    onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-white"
                  >
                    <option value="Sizing & Fit Advisory">Sizing & Fit Advisory</option>
                    <option value="Bespoke Cordwaining / Made-to-Measure">Bespoke Cordwaining / Made-to-Measure</option>
                    <option value="Private Atelier Appointment">Private Atelier Appointment (Milan/Florence)</option>
                    <option value="Order Tracking & Express Delivery">Order Tracking & Express Delivery</option>
                    <option value="Wholesale & Trunk Shows">Wholesale & Trunk Shows</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Order Number (if applicable)</label>
                  <input
                    type="text"
                    placeholder="e.g. NW-2026-1049"
                    value={formData.orderNumber}
                    onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Your Message or Fit Query *</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Tell us about the piece you are considering, your typical dress shoe size, or preferred appointment dates..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Submit Concierge Inquiry
              </button>
            </form>
          )}
        </div>

        {/* FAQ Accordion Column */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-4">
          <h2 className="text-xl font-bold text-stone-950 font-display">
            Frequently Addressed Questions
          </h2>
          <p className="text-xs text-stone-500 mb-4">
            Immediate answers to key inquiries regarding sizing, resole care, and international express dispatch.
          </p>

          <div className="divide-y divide-stone-100">
            {faqs.map((faq, idx) => (
              <div key={idx} className="py-3">
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full flex items-center justify-between text-left text-xs font-bold text-stone-900 gap-2"
                >
                  <span>{faq.q}</span>
                  {openFaq === idx ? (
                    <ChevronUp className="w-4 h-4 text-stone-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-stone-400 shrink-0" />
                  )}
                </button>
                {openFaq === idx && (
                  <p className="text-xs text-stone-600 leading-relaxed pt-2">
                    {faq.a}
                  </p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-stone-100 flex items-center gap-2 text-xs text-stone-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Dedicated European Cordwainer Support Team</span>
          </div>
        </div>

      </div>

    </div>
  );
};
