import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { CheckoutFormData } from '../types';
import { BRAND_LOGO_SRC } from '../data/products';
import { ShieldCheck, Lock, CreditCard, Check, ArrowLeft, Truck, Package, PhoneCall } from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const { cart, cartSubtotal, discountAmount, cartTotal, appliedCoupon, clearCart, navigateTo, createOrder } = useShop();

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  // Form states
  const [formData, setFormData] = useState<CheckoutFormData>({
    email: 'client@nikkiworld.com',
    phone: '+1 (555) 382-9102',
    firstName: 'Julian',
    lastName: 'Vance',
    address: '450 Park Avenue, Suite 1800',
    apartment: 'Floor 18',
    city: 'New York',
    state: 'NY',
    postalCode: '10022',
    country: 'United States',
    deliveryOption: 'standard',
    paymentMethod: 'card',
    cardNumber: '•••• •••• •••• 4242',
    cardExpiry: '08/28',
    cardCvc: '884',
    saveInfo: true
  });

  const handleChange = (field: keyof CheckoutFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrder = createOrder(formData);
    setOrderNumber(newOrder.id);
    setOrderConfirmed(true);
    clearCart();
  };

  if (orderConfirmed) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600 shadow-md">
          <Check className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-[#B3541E]">
            Artisan Commission Confirmed
          </span>
          <h1 className="text-3xl font-extrabold text-stone-950 font-display">
            Thank You for Your Patronage
          </h1>
          <p className="text-sm text-stone-600 max-w-md mx-auto">
            Order <strong className="text-stone-900 font-mono">{orderNumber}</strong> has been received by our master cordwainers and will be packaged with signature presentation.
          </p>
        </div>

        {/* Confirmation Details Card */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 text-left space-y-6 shadow-sm">
          <div className="flex items-center justify-between border-b border-stone-200 pb-4">
            <div>
              <span className="text-xs text-stone-400 block">Recipient</span>
              <strong className="text-sm text-stone-900">{formData.firstName} {formData.lastName}</strong>
            </div>
            <div>
              <span className="text-xs text-stone-400 block">Delivery Method</span>
              <strong className="text-sm text-stone-900">
                {formData.deliveryOption === 'standard' ? 'Complimentary DHL Express (3-5 Days)' : 'Priority Overnight Express ($25)'}
              </strong>
            </div>
            <div>
              <span className="text-xs text-stone-400 block">Payment</span>
              <strong className="text-sm text-stone-900 uppercase">
                {formData.paymentMethod === 'card' ? 'Credit Card' : formData.paymentMethod === 'apple_pay' ? 'Apple Pay' : 'Cash on Delivery'}
              </strong>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-3">
              Shipping Destination
            </h4>
            <p className="text-xs text-stone-700 leading-relaxed">
              {formData.address} {formData.apartment && `(${formData.apartment})`}<br />
              {formData.city}, {formData.state} {formData.postalCode}<br />
              {formData.country}
            </p>
            <p className="text-xs text-stone-500 mt-2">
              Updates sent to: <strong className="text-stone-800">{formData.email}</strong> · {formData.phone}
            </p>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-center gap-3">
            <Package className="w-5 h-5 text-[#F5B301] shrink-0" />
            <div className="text-xs text-stone-600">
              <strong className="text-stone-900 block">Nikki World Bespoke Packaging</strong>
              <span>Each order includes cedar shoetrees / hat forms, silk dust bags, and prepaid DHL return credentials.</span>
            </div>
          </div>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row justify-center gap-4">
          <button
            onClick={() => navigateTo('home')}
            className="px-8 py-3.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-colors"
          >
            Return to Homepage
          </button>
          <button
            onClick={() => navigateTo('shop')}
            className="px-6 py-3.5 bg-white border border-stone-300 text-stone-800 font-semibold text-xs rounded-xl hover:border-stone-900 transition-colors"
          >
            Explore More Atelier Drops
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-6 border-b border-stone-200">
        <button
          onClick={() => navigateTo('cart')}
          className="text-xs text-stone-500 hover:text-stone-950 flex items-center gap-1.5 font-medium"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Shopping Bag</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-stone-500">
          <Lock className="w-3.5 h-3.5 text-emerald-600" />
          <span>256-Bit SSL Encrypted Checkout</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        
        {/* Left: Interactive Multi-Step Checkout Form */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Step 1: Customer Contact & Shipping Address */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-stone-950 text-white text-xs font-bold flex items-center justify-center">
                  1
                </span>
                <h2 className="text-base font-bold text-stone-950 font-display">
                  Contact & Shipping Address
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-stone-700 font-medium mb-1">Email Address (for order tracking)</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Phone Number (courier delivery alert)</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">First Name</label>
                <input
                  type="text"
                  required
                  value={formData.firstName}
                  onChange={(e) => handleChange('firstName', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Last Name</label>
                <input
                  type="text"
                  required
                  value={formData.lastName}
                  onChange={(e) => handleChange('lastName', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-stone-700 font-medium mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Apartment, Suite, Unit</label>
                <input
                  type="text"
                  value={formData.apartment}
                  onChange={(e) => handleChange('apartment', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">City</label>
                <input
                  type="text"
                  required
                  value={formData.city}
                  onChange={(e) => handleChange('city', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">State / Region</label>
                <input
                  type="text"
                  required
                  value={formData.state}
                  onChange={(e) => handleChange('state', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Postal / ZIP Code</label>
                <input
                  type="text"
                  required
                  value={formData.postalCode}
                  onChange={(e) => handleChange('postalCode', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-900 bg-stone-50/50"
                />
              </div>
            </div>
          </div>

          {/* Step 2: Delivery Method */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-stone-950 text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h2 className="text-base font-bold text-stone-950 font-display">
                Delivery Method
              </h2>
            </div>

            <div className="space-y-3">
              <label
                className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                  formData.deliveryOption === 'standard'
                    ? 'border-stone-950 bg-stone-50/80 ring-1 ring-stone-950'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="delivery"
                    checked={formData.deliveryOption === 'standard'}
                    onChange={() => handleChange('deliveryOption', 'standard')}
                    className="accent-stone-950"
                  />
                  <div>
                    <strong className="text-xs text-stone-900 block font-semibold">
                      Complimentary DHL Express Worldwide
                    </strong>
                    <span className="text-[11px] text-stone-500">Delivered within 3–5 business days · Insured signature delivery</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 uppercase">FREE</span>
              </label>

              <label
                className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                  formData.deliveryOption === 'express'
                    ? 'border-stone-950 bg-stone-50/80 ring-1 ring-stone-950'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="delivery"
                    checked={formData.deliveryOption === 'express'}
                    onChange={() => handleChange('deliveryOption', 'express')}
                    className="accent-stone-950"
                  />
                  <div>
                    <strong className="text-xs text-stone-900 block font-semibold">
                      Priority Next-Flight Express
                    </strong>
                    <span className="text-[11px] text-stone-500">Delivered next business day by 12:00 PM</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-stone-900 tabular-nums">+$25.00</span>
              </label>
            </div>
          </div>

          {/* Step 3: Payment Method */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-5">
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-stone-950 text-white text-xs font-bold flex items-center justify-center">
                3
              </span>
              <h2 className="text-base font-bold text-stone-950 font-display">
                Payment Method
              </h2>
            </div>

            {/* Payment Options Selector */}
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => handleChange('paymentMethod', 'card')}
                className={`py-3 px-2 rounded-xl border text-center transition-all ${
                  formData.paymentMethod === 'card'
                    ? 'border-stone-950 bg-stone-900 text-white font-bold'
                    : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                }`}
              >
                <CreditCard className="w-4 h-4 mx-auto mb-1" />
                <span className="text-[11px] block">Credit Card</span>
              </button>

              <button
                type="button"
                onClick={() => handleChange('paymentMethod', 'apple_pay')}
                className={`py-3 px-2 rounded-xl border text-center transition-all ${
                  formData.paymentMethod === 'apple_pay'
                    ? 'border-stone-950 bg-stone-900 text-white font-bold'
                    : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                }`}
              >
                <span className="font-bold text-sm block mb-1">Pay</span>
                <span className="text-[11px] block">Apple / Google</span>
              </button>

              <button
                type="button"
                onClick={() => handleChange('paymentMethod', 'cod')}
                className={`py-3 px-2 rounded-xl border text-center transition-all ${
                  formData.paymentMethod === 'cod'
                    ? 'border-stone-950 bg-stone-900 text-white font-bold'
                    : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                }`}
              >
                <PhoneCall className="w-4 h-4 mx-auto mb-1" />
                <span className="text-[11px] block">Cash on Delivery</span>
              </button>
            </div>

            {/* Payment Details Container */}
            {formData.paymentMethod === 'card' && (
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 space-y-3 text-xs">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Card Number</label>
                  <input
                    type="text"
                    value={formData.cardNumber}
                    onChange={(e) => handleChange('cardNumber', e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-700 font-medium mb-1">Expiration (MM/YY)</label>
                    <input
                      type="text"
                      value={formData.cardExpiry}
                      onChange={(e) => handleChange('cardExpiry', e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-700 font-medium mb-1">Security Code (CVC)</label>
                    <input
                      type="text"
                      value={formData.cardCvc}
                      onChange={(e) => handleChange('cardCvc', e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {formData.paymentMethod === 'apple_pay' && (
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 text-center text-xs space-y-2">
                <p className="text-stone-700">
                  Biometric one-touch payment will be confirmed upon placing order.
                </p>
                <span className="inline-block px-4 py-2 bg-stone-950 text-white rounded-lg font-bold text-xs">
                  Pay with Pay
                </span>
              </div>
            )}

            {formData.paymentMethod === 'cod' && (
              <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-stone-700 space-y-1.5">
                <strong className="text-stone-900 block font-semibold">Cash on Delivery Verification:</strong>
                <p>
                  You will pay cash or card upon arrival of your DHL courier. Please ensure valid contact phone number is reachable for delivery schedule verification.
                </p>
              </div>
            )}

            {/* Place Order Trigger */}
            <div className="pt-2">
              <button
                onClick={handlePlaceOrder}
                className="w-full py-4 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-sm uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-5 h-5" />
                <span>Authorize & Place Order (${cartTotal + (formData.deliveryOption === 'express' ? 25 : 0)})</span>
              </button>
            </div>
          </div>

        </div>

        {/* Right: Order Summary Sidebar */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-5 lg:sticky lg:top-28">
          <h3 className="text-base font-bold text-stone-950 font-display pb-3 border-b border-stone-200">
            Order Review ({cart.length} items)
          </h3>

          {/* Items thumbnail list */}
          <div className="divide-y divide-stone-100 max-h-72 overflow-y-auto pr-1">
            {cart.map((item) => (
              <div key={item.id} className="py-3 first:pt-0 last:pb-0 flex items-center gap-3">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-lg object-cover bg-stone-100 border border-stone-200 shrink-0"
                />
                <div className="flex-1 min-w-0 text-xs">
                  <h4 className="font-bold text-stone-900 truncate">{item.product.name}</h4>
                  <span className="text-stone-500 text-[11px] block">{item.selectedSize} · {item.selectedColor}</span>
                  <span className="text-stone-400 text-[10px]">Qty: {item.quantity}</span>
                </div>
                <span className="text-xs font-bold text-stone-950 tabular-nums">
                  ${item.price * item.quantity}
                </span>
              </div>
            ))}
          </div>

          {/* Calculation */}
          <div className="space-y-2 text-xs text-stone-600 pt-3 border-t border-stone-200">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-medium text-stone-900 tabular-nums">${cartSubtotal}</span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Promotional Discount (20%)</span>
                <span className="font-medium tabular-nums">-${discountAmount}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span>Delivery</span>
              <span className="font-medium text-stone-900">
                {formData.deliveryOption === 'standard' ? (
                  <strong className="text-emerald-700">FREE</strong>
                ) : (
                  '+$25.00'
                )}
              </span>
            </div>

            <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline text-base font-extrabold text-stone-950">
              <span>Total Due</span>
              <span className="text-xl tabular-nums font-display">
                ${cartTotal + (formData.deliveryOption === 'express' ? 25 : 0)}
              </span>
            </div>
          </div>

          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-[11px] text-stone-500 space-y-1">
            <p><strong>Nikki World Guarantee:</strong> Free 30-day returns and exchanges worldwide. All orders covered by transit damage insurance.</p>
          </div>
        </div>

      </div>

    </div>
  );
};
