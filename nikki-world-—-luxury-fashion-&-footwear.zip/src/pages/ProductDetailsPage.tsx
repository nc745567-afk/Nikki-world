import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS, SAMPLE_REVIEWS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import {
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  Ruler,
  Check,
  ChevronDown,
  ChevronUp,
  ShoppingBag,
  Zap,
  Heart,
  Share2,
  X
} from 'lucide-react';

export const ProductDetailsPage: React.FC = () => {
  const { selectedProductId, addToCart, navigateTo, toggleWishlist, isWishlisted, showToast, products } = useShop();

  // Find product or fallback to first product
  const product = products.find((p) => p.id === selectedProductId) || products[0];
  const wishlisted = isWishlisted(product.id);

  // Gallery state
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Variant selections
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || 'Standard');
  const [sizeFormat, setSizeFormat] = useState<'US' | 'EU'>('US');
  const [selectedSize, setSelectedSize] = useState(
    product.sizes.find((s) => s.stock !== 'out_of_stock')?.size || product.sizes[0].size
  );
  const [quantity, setQuantity] = useState(1);

  // Accordion states
  const [openAccordion, setOpenAccordion] = useState<'craftsmanship' | 'fit' | 'shipping' | null>('craftsmanship');

  // Size guide modal state
  const [showSizeGuide, setShowSizeGuide] = useState(false);

  // Cross-sell products ("Complete the Look")
  const crossSellProducts = products.filter((p) => p.id !== product.id).slice(0, 2);

  const toggleAccordion = (key: 'craftsmanship' | 'fit' | 'shipping') => {
    setOpenAccordion(openAccordion === key ? null : key);
  };

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
  };

  const handleInstantBuy = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    navigateTo('checkout');
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Product link copied to clipboard');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      
      {/* Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="text-xs text-stone-500 flex items-center gap-2">
        <button onClick={() => navigateTo('home')} className="hover:text-stone-900 transition-colors">
          Home
        </button>
        <span>/</span>
        <button onClick={() => navigateTo('shop')} className="hover:text-stone-900 transition-colors">
          {product.category}
        </button>
        <span>/</span>
        <span className="text-stone-900 font-medium truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main PDP Grid: Gallery (Left) & Contiguous Purchase Module (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
        
        {/* Left: Multi-Image Showcase Gallery */}
        <div className="lg:col-span-7 space-y-4 lg:sticky lg:top-28">
          {/* Main Showcase Image */}
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-sm">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transition-all duration-300"
            />

            {/* Badges Overlay */}
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              {product.badge && (
                <span className="px-3 py-1 text-xs font-bold tracking-wider uppercase rounded bg-stone-900 text-white shadow-sm">
                  {product.badge}
                </span>
              )}
              <span className="px-2.5 py-1 text-[11px] font-semibold tracking-wider uppercase rounded bg-white/90 backdrop-blur-xs text-stone-800 shadow-sm border border-stone-200">
                Handmade in Tuscany
              </span>
            </div>

            {/* Action Overlays (Wishlist + Share) */}
            <div className="absolute top-4 right-4 flex items-center gap-2">
              <button
                onClick={handleShare}
                className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-xs hover:bg-white text-stone-700 flex items-center justify-center shadow-sm transition-colors"
                aria-label="Share product"
              >
                <Share2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => toggleWishlist(product.id)}
                className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-xs hover:bg-white text-stone-700 flex items-center justify-center shadow-sm transition-colors"
                aria-label={wishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
              >
                <Heart className={`w-4 h-4 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
              </button>
            </div>

            {/* Slide Index Pill */}
            <div className="absolute bottom-4 right-4 px-3 py-1 rounded-full bg-stone-950/70 backdrop-blur-xs text-white text-xs font-mono font-medium">
              {activeImageIndex + 1} / {product.images.length}
            </div>
          </div>

          {/* Thumbnail Strip */}
          <div className="flex items-center gap-3 overflow-x-auto pb-2">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImageIndex(idx)}
                className={`relative w-24 h-20 rounded-xl overflow-hidden bg-stone-100 border-2 transition-all shrink-0 cursor-pointer ${
                  activeImageIndex === idx ? 'border-stone-900 ring-2 ring-stone-900/20' : 'border-stone-200 opacity-70 hover:opacity-100'
                }`}
              >
                <img
                  src={img}
                  alt={`${product.name} angle ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>

          {/* Value Guarantees Banner below gallery */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-stone-200 text-stone-600 text-xs">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#F5B301] shrink-0" />
              <span>Complimentary Express Shipping</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-[#F5B301] shrink-0" />
              <span>30-Day Bespoke Returns</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#F5B301] shrink-0" />
              <span>Certified Tuscan Tannery</span>
            </div>
          </div>
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="lg:col-span-5 space-y-6 bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-sm">
          
          {/* Header & Title */}
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span className="uppercase tracking-widest font-bold text-[#B3541E]">
                {product.category} · Artisanal Heritage
              </span>
              <span className="font-mono text-stone-400 text-[11px]">{product.sku}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display leading-tight">
              {product.name}
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              {product.subtitle}
            </p>

            {/* Ratings Summary */}
            <div className="flex items-center gap-2 mt-3 text-xs">
              <div className="flex items-center text-[#F5B301]">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-stone-300'}`}
                  />
                ))}
              </div>
              <span className="font-bold text-stone-900 tabular-nums">{product.rating.toFixed(2)}</span>
              <span className="text-stone-400">·</span>
              <span className="text-stone-600 font-medium underline cursor-pointer">
                {product.reviewsCount} verified reviews
              </span>
            </div>
          </div>

          {/* Pricing & Split-Pay */}
          <div className="p-4 rounded-xl bg-stone-50 border border-stone-200/80 space-y-2">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold text-stone-950 tabular-nums font-display">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-base text-stone-400 line-through tabular-nums">
                  ${product.originalPrice}
                </span>
              )}
              {product.originalPrice && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                  Save ${product.originalPrice - product.price}
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500">
              Or 4 interest-free installments of <strong className="text-stone-900">${(product.price / 4).toFixed(2)}</strong> with Klarna or Afterpay.
            </p>
          </div>

          {/* Colorway Swatches */}
          <div>
            <div className="flex justify-between items-center text-xs font-semibold text-stone-800 mb-2">
              <span>Colorway: <strong className="text-stone-950 font-bold">{selectedColor}</strong></span>
              <span className="text-stone-400 text-[11px]">{product.colors.length} choices</span>
            </div>
            <div className="flex items-center gap-2.5">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setSelectedColor(c.name)}
                  className={`w-9 h-9 rounded-full border-2 flex items-center justify-center transition-all cursor-pointer ${
                    selectedColor === c.name
                      ? 'border-[#F5B301] ring-2 ring-[#F5B301]/40 scale-105'
                      : 'border-stone-300 hover:border-stone-500'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                >
                  {selectedColor === c.name && (
                    <Check className="w-4 h-4 text-white drop-shadow" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector with US / EU Tabs & Size Guide Trigger */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-stone-800">Select Size:</span>
                <div className="inline-flex rounded-md p-0.5 bg-stone-200 text-[10px] font-bold">
                  <button
                    onClick={() => setSizeFormat('US')}
                    className={`px-2 py-0.5 rounded transition-all ${sizeFormat === 'US' ? 'bg-white shadow-xs text-stone-900' : 'text-stone-600'}`}
                  >
                    US
                  </button>
                  <button
                    onClick={() => setSizeFormat('EU')}
                    className={`px-2 py-0.5 rounded transition-all ${sizeFormat === 'EU' ? 'bg-white shadow-xs text-stone-900' : 'text-stone-600'}`}
                  >
                    EU
                  </button>
                </div>
              </div>

              <button
                onClick={() => setShowSizeGuide(true)}
                className="text-xs text-[#B3541E] hover:underline flex items-center gap-1 font-semibold"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Size Guide</span>
              </button>
            </div>

            {/* Size Tiles */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {product.sizes.map((s) => {
                const isSelected = selectedSize === s.size;
                const isOut = s.stock === 'out_of_stock';
                const isLow = s.stock === 'low_stock';

                return (
                  <button
                    key={s.size}
                    disabled={isOut}
                    onClick={() => setSelectedSize(s.size)}
                    className={`p-2 rounded-lg border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'border-stone-950 bg-stone-950 text-white font-bold ring-2 ring-stone-950/20'
                        : isOut
                        ? 'border-stone-200 bg-stone-100 text-stone-300 line-through cursor-not-allowed'
                        : 'border-stone-200 bg-white text-stone-800 hover:border-stone-400'
                    }`}
                  >
                    <span className="text-xs font-medium">
                      {sizeFormat === 'US' ? s.size.split('/')[0].trim() : s.size.split('/')[1]?.trim() || s.size}
                    </span>
                    <span className={`text-[9px] mt-1 ${isSelected ? 'text-amber-300' : isLow ? 'text-amber-700 font-bold' : 'text-stone-400'}`}>
                      {isOut ? 'Sold Out' : isLow ? 'Low Stock' : 'In Stock'}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Fit recommendation advisory */}
            <div className="mt-2.5 p-2.5 rounded-lg bg-stone-50 border border-stone-200/60 text-[11px] text-stone-600 flex items-center gap-2">
              <span className="text-[#F5B301] font-bold">ℹ</span>
              <span><strong>Fit Advisory:</strong> {product.specs.fitRecommendation}</span>
            </div>
          </div>

          {/* Quantity Stepper & Dual Action Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 px-2 py-1">
                <span className="text-xs text-stone-500 font-medium mr-2">Qty:</span>
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-7 h-7 flex items-center justify-center text-stone-700 hover:text-stone-950 font-bold"
                  aria-label="Decrease quantity"
                >
                  -
                </button>
                <span className="w-8 text-center text-xs font-bold text-stone-900 tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-7 h-7 flex items-center justify-center text-stone-700 hover:text-stone-950 font-bold"
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>

              {/* Add to Bag Button */}
              <button
                onClick={handleAddToCart}
                className="flex-1 py-3.5 px-4 bg-stone-950 hover:bg-stone-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Bag (${product.price * quantity})</span>
              </button>
            </div>

            {/* High-Conversion Golden Instant Buy CTA */}
            <button
              onClick={handleInstantBuy}
              className="w-full py-3.5 px-4 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>Instant Buy with Express Checkout</span>
            </button>
          </div>

          {/* Product Specifications Accordions */}
          <div className="border-t border-stone-200 pt-4 divide-y divide-stone-200">
            {/* Accordion 1 */}
            <div className="py-3">
              <button
                onClick={() => toggleAccordion('craftsmanship')}
                className="w-full flex items-center justify-between text-xs font-bold text-stone-900 uppercase tracking-wider text-left"
              >
                <span>Craftsmanship & Italian Materials</span>
                {openAccordion === 'craftsmanship' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openAccordion === 'craftsmanship' && (
                <div className="pt-3 text-xs text-stone-600 leading-relaxed space-y-2">
                  <p>{product.specs.craftsmanship}</p>
                  <p><strong>Composition:</strong> {product.specs.materials}</p>
                  <ul className="list-disc pl-4 space-y-1 pt-1 text-stone-500">
                    {product.features.map((feat, idx) => (
                      <li key={idx}>{feat}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Accordion 2 */}
            <div className="py-3">
              <button
                onClick={() => toggleAccordion('fit')}
                className="w-full flex items-center justify-between text-xs font-bold text-stone-900 uppercase tracking-wider text-left"
              >
                <span>Fit & Measurement Guide</span>
                {openAccordion === 'fit' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openAccordion === 'fit' && (
                <div className="pt-3 text-xs text-stone-600 leading-relaxed space-y-2">
                  <p>{product.specs.fitRecommendation}</p>
                  <p>Our cordwainers utilize standard European lasts. We recommend selecting your true formal footwear size.</p>
                </div>
              )}
            </div>

            {/* Accordion 3 */}
            <div className="py-3">
              <button
                onClick={() => toggleAccordion('shipping')}
                className="w-full flex items-center justify-between text-xs font-bold text-stone-900 uppercase tracking-wider text-left"
              >
                <span>Complimentary Shipping & 30-Day Returns</span>
                {openAccordion === 'shipping' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openAccordion === 'shipping' && (
                <div className="pt-3 text-xs text-stone-600 leading-relaxed space-y-2">
                  <p>{product.specs.shipping}</p>
                  <p>Each parcel is double-boxed and includes prepaid DHL return postage.</p>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* "Complete the Look" Curated Ensemble Cross-Sell */}
      <section className="bg-stone-100/70 rounded-2xl p-6 sm:p-8 border border-stone-200">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block mb-1">
              Atelier Styling Recommendations
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-stone-950 font-display">
              Complete The Look
            </h3>
          </div>
          <span className="text-xs text-stone-500">Curated ensemble pairing</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {crossSellProducts.map((p) => (
            <div key={p.id} className="bg-white p-4 rounded-xl border border-stone-200 flex items-center gap-4">
              <img
                src={p.images[0]}
                alt={p.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 object-cover rounded-lg bg-stone-100 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] uppercase font-bold text-stone-400 block">{p.category}</span>
                <h4 className="text-xs font-bold text-stone-900 truncate">{p.name}</h4>
                <span className="text-xs font-bold text-stone-950 tabular-nums block mt-1">${p.price}</span>
              </div>
              <button
                onClick={() => {
                  addToCart(p, p.sizes[0].size, p.colors[0].name, 1);
                }}
                className="px-3 py-2 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs rounded-lg shrink-0 transition-colors"
              >
                + Add
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Customer Reviews Section */}
      <section className="border-t border-stone-200 pt-12 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-stone-200">
          <div>
            <h3 className="text-2xl font-extrabold text-stone-950 font-display">
              Customer Reviews
            </h3>
            <div className="flex items-center gap-3 mt-2">
              <div className="flex items-center text-[#F5B301]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" />
                ))}
              </div>
              <span className="text-lg font-bold text-stone-950 tabular-nums font-display">
                {product.rating.toFixed(2)} out of 5
              </span>
              <span className="text-xs text-stone-500">Based on {product.reviewsCount} verified purchases</span>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-stone-50 px-5 py-3 rounded-xl border border-stone-200">
            <div className="text-center">
              <span className="text-xl font-bold text-stone-950 block font-display">98%</span>
              <span className="text-[10px] text-stone-500 uppercase tracking-wider">Recommend</span>
            </div>
            <div className="h-8 w-px bg-stone-200" />
            <div className="text-center">
              <span className="text-xl font-bold text-stone-950 block font-display">100%</span>
              <span className="text-[10px] text-stone-500 uppercase tracking-wider">Genuine Tuscan</span>
            </div>
          </div>
        </div>

        {/* Reviews List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SAMPLE_REVIEWS.map((r) => (
            <div key={r.id} className="p-5 rounded-xl bg-white border border-stone-200 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 text-[#F5B301]">
                  {[...Array(r.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>
                <span className="text-stone-400">{r.date}</span>
              </div>
              <h4 className="text-xs font-bold text-stone-900">"{r.title}"</h4>
              <p className="text-xs text-stone-600 leading-relaxed">{r.comment}</p>
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                <span>{r.author} · {r.location}</span>
                <span className="text-emerald-700 font-medium">✓ Verified Buyer</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Size Guide Modal */}
      {showSizeGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setShowSizeGuide(false)} className="absolute inset-0 bg-stone-950/70 backdrop-blur-xs" />
          <div className="relative bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl z-10 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-bold text-stone-950 font-display">Footwear & Millinery Size Guide</h3>
              <button onClick={() => setShowSizeGuide(false)} className="text-stone-400 hover:text-stone-950">
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <p className="text-xs text-stone-600">
              Nikki World footwear is built on Italian lasts that run true to traditional European luxury sizing.
            </p>

            <table className="w-full text-xs text-left border border-stone-200 divide-y divide-stone-200">
              <thead className="bg-stone-50 font-semibold text-stone-700">
                <tr>
                  <th className="p-2.5">US Men</th>
                  <th className="p-2.5">EU Size</th>
                  <th className="p-2.5">UK Size</th>
                  <th className="p-2.5">Foot Length</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 tabular-nums">
                <tr><td className="p-2">8.0</td><td className="p-2">41</td><td className="p-2">7.0</td><td className="p-2">26.0 cm</td></tr>
                <tr><td className="p-2">8.5</td><td className="p-2">42</td><td className="p-2">7.5</td><td className="p-2">26.5 cm</td></tr>
                <tr><td className="p-2">9.0</td><td className="p-2">42.5</td><td className="p-2">8.0</td><td className="p-2">27.0 cm</td></tr>
                <tr><td className="p-2">9.5</td><td className="p-2">43</td><td className="p-2">8.5</td><td className="p-2">27.5 cm</td></tr>
                <tr><td className="p-2">10.0</td><td className="p-2">44</td><td className="p-2">9.0</td><td className="p-2">28.0 cm</td></tr>
                <tr><td className="p-2">10.5</td><td className="p-2">44.5</td><td className="p-2">9.5</td><td className="p-2">28.5 cm</td></tr>
                <tr><td className="p-2">11.0</td><td className="p-2">45</td><td className="p-2">10.0</td><td className="p-2">29.0 cm</td></tr>
              </tbody>
            </table>

            <div className="pt-2">
              <button
                onClick={() => setShowSizeGuide(false)}
                className="w-full py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
