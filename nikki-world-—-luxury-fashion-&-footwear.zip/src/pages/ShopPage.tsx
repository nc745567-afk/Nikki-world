import React, { useState, useMemo } from 'react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { useShop } from '../context/ShopContext';
import { Search, SlidersHorizontal, ArrowUpDown, X, Grid, LayoutList } from 'lucide-react';

export const ShopPage: React.FC = () => {
  const { navigateTo, products } = useShop();
  
  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedGender, setSelectedGender] = useState<string>('All');
  const [maxPrice, setMaxPrice] = useState<number>(700);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating' | 'newest'>('featured');
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filter & sort logic
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesCategory = product.category.toLowerCase().includes(query);
        const matchesSubtitle = product.subtitle.toLowerCase().includes(query);
        if (!matchesName && !matchesCategory && !matchesSubtitle) return false;
      }

      // Category match
      if (selectedCategory !== 'All' && product.category !== selectedCategory) {
        return false;
      }

      // Gender match
      if (selectedGender !== 'All' && product.gender !== selectedGender && product.gender !== 'Unisex') {
        return false;
      }

      // Price match
      if (product.price > maxPrice) {
        return false;
      }

      // In stock match
      if (inStockOnly) {
        const hasStock = product.sizes.some((s) => s.stock !== 'out_of_stock');
        if (!hasStock) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'newest') return (b.badge === 'NEW SEASON' ? 1 : 0) - (a.badge === 'NEW SEASON' ? 1 : 0);
      return 0; // featured default
    });
  }, [searchQuery, selectedCategory, selectedGender, maxPrice, inStockOnly, sortBy]);

  const categories = ['All', 'Footwear', 'Hats', 'Tailoring', 'Women', 'Accessories'];

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedGender('All');
    setMaxPrice(700);
    setInStockOnly(false);
    setSortBy('featured');
  };

  const hasActiveFilters = searchQuery !== '' || selectedCategory !== 'All' || selectedGender !== 'All' || maxPrice < 700 || inStockOnly;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* 1. Header & Title Banner */}
      <div className="border-b border-stone-200 pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block mb-1">
              Nikki World Catalog
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-stone-950 font-display">
              Curated Sartorial Collection
            </h1>
            <p className="text-xs text-stone-500 mt-1 max-w-xl">
              Authentic Italian cordwaining, hand-blocked merino wool fedoras, and bespoke outerwear.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-stone-500 font-medium">
              Showing <strong className="text-stone-900 tabular-nums">{filteredProducts.length}</strong> styles
            </span>

            {/* View mode toggle */}
            <div className="flex items-center p-1 bg-stone-100 rounded-lg border border-stone-200">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded transition-colors ${viewMode === 'grid' ? 'bg-white shadow-xs text-stone-950' : 'text-stone-500'}`}
                aria-label="Grid view"
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded transition-colors ${viewMode === 'list' ? 'bg-white shadow-xs text-stone-950' : 'text-stone-500'}`}
                aria-label="List view"
              >
                <LayoutList className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Controls Bar: Search, Category Tabs, Filters Trigger, Sort Dropdown */}
      <div className="space-y-4">
        
        {/* Row 1: Search & Sort & Filter Toggle */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              placeholder="Search oxfords, chelsea boots, fedora hats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-8 py-2.5 bg-white border border-stone-300 rounded-xl text-xs focus:outline-none focus:border-stone-950 focus:ring-1 focus:ring-stone-950"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Right Action Cluster */}
          <div className="flex items-center gap-3">
            {/* Filter Drawer Toggle */}
            <button
              onClick={() => setFilterDrawerOpen(!filterDrawerOpen)}
              className={`px-4 py-2.5 border rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
                filterDrawerOpen || hasActiveFilters
                  ? 'bg-stone-900 border-stone-900 text-white'
                  : 'bg-white border-stone-300 text-stone-700 hover:border-stone-400'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters {hasActiveFilters && '•'}</span>
            </button>

            {/* Sort Selector */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="appearance-none bg-white border border-stone-300 rounded-xl pl-3 pr-8 py-2.5 text-xs font-semibold text-stone-800 focus:outline-none focus:border-stone-950 cursor-pointer"
              >
                <option value="featured">Sort: Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="newest">New Season First</option>
              </select>
              <ArrowUpDown className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Row 2: Category Segmented Controls (Buttons) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-stone-950 text-white font-semibold shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-600 hover:text-stone-950 hover:border-stone-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Row 3: Active Filters Tags Bar */}
        {hasActiveFilters && (
          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
            <span className="text-stone-500 font-medium">Active:</span>

            {selectedCategory !== 'All' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-stone-100 rounded-md text-stone-800 font-medium">
                Category: {selectedCategory}
                <button onClick={() => setSelectedCategory('All')} className="text-stone-400 hover:text-stone-800">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {searchQuery && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-stone-100 rounded-md text-stone-800 font-medium">
                "{searchQuery}"
                <button onClick={() => setSearchQuery('')} className="text-stone-400 hover:text-stone-800">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {maxPrice < 700 && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-stone-100 rounded-md text-stone-800 font-medium">
                Under ${maxPrice}
                <button onClick={() => setMaxPrice(700)} className="text-stone-400 hover:text-stone-800">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {inStockOnly && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-stone-100 rounded-md text-stone-800 font-medium">
                In Stock Only
                <button onClick={() => setInStockOnly(false)} className="text-stone-400 hover:text-stone-800">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            <button
              onClick={resetFilters}
              className="text-[#B3541E] hover:underline font-semibold text-xs ml-2"
            >
              Clear All
            </button>
          </div>
        )}
      </div>

      {/* 3. Main Catalog Layout: Filter Drawer + Product Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        
        {/* Filter Drawer / Sidebar */}
        {filterDrawerOpen && (
          <aside className="lg:col-span-1 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-bold text-sm text-stone-900 uppercase tracking-wider font-display">
                Filter Collection
              </h3>
              <button
                onClick={() => setFilterDrawerOpen(false)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Price Range Slider */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold text-stone-800 mb-2">
                <span>Maximum Price</span>
                <span className="tabular-nums text-stone-950 font-bold">${maxPrice}</span>
              </div>
              <input
                type="range"
                min="100"
                max="700"
                step="25"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#F5B301] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-stone-400 mt-1">
                <span>$100</span>
                <span>$700</span>
              </div>
            </div>

            {/* Gender Filter */}
            <div>
              <span className="text-xs font-semibold text-stone-800 block mb-2">
                Audience
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {['All', 'Men', 'Women'].map((gender) => (
                  <button
                    key={gender}
                    onClick={() => setSelectedGender(gender)}
                    className={`py-1.5 text-xs rounded border transition-colors ${
                      selectedGender === gender
                        ? 'bg-stone-900 border-stone-900 text-white font-semibold'
                        : 'bg-white border-stone-200 text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    {gender}
                  </button>
                ))}
              </div>
            </div>

            {/* In Stock Toggle */}
            <div className="pt-2 border-t border-stone-100">
              <label className="flex items-center gap-2.5 text-xs text-stone-800 font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  className="rounded text-stone-900 focus:ring-stone-900 accent-stone-900 w-4 h-4"
                />
                <span>Ready to Ship (In Stock Only)</span>
              </label>
            </div>

            {/* Apply & Reset in Drawer */}
            <div className="pt-4 border-t border-stone-200 flex gap-2">
              <button
                onClick={() => setFilterDrawerOpen(false)}
                className="flex-1 py-2 bg-stone-950 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors"
              >
                Apply Filters
              </button>
              <button
                onClick={resetFilters}
                className="px-3 py-2 bg-stone-100 text-stone-600 text-xs font-medium rounded-lg hover:bg-stone-200"
              >
                Reset
              </button>
            </div>
          </aside>
        )}

        {/* Product Grid Area */}
        <div className={filterDrawerOpen ? 'lg:col-span-3' : 'lg:col-span-4'}>
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-4">
              <h3 className="text-lg font-bold text-stone-800">No styles matched your criteria</h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Try widening your price range or clearing category filters to view our full collection.
              </p>
              <button
                onClick={resetFilters}
                className="px-5 py-2.5 bg-[#F5B301] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-[#E0A200] transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            <div className={`grid grid-cols-1 sm:grid-cols-2 ${filterDrawerOpen ? 'lg:grid-cols-3' : 'lg:grid-cols-4'} gap-6`}>
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            /* List Detailed View */
            <div className="space-y-4">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  onClick={() => navigateTo('product-details', product.id)}
                  className="bg-white rounded-xl border border-stone-200 p-4 flex flex-col sm:flex-row gap-5 items-center hover:shadow-md transition-all cursor-pointer group"
                >
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full sm:w-44 aspect-[4/3] object-cover rounded-lg bg-stone-100"
                  />
                  <div className="flex-1 space-y-1.5 w-full">
                    <div className="flex items-center justify-between text-xs text-stone-400">
                      <span className="uppercase tracking-wider font-semibold text-[11px] text-stone-600">{product.category}</span>
                      <span className="text-[#F5B301] font-bold">★ {product.rating.toFixed(1)} ({product.reviewsCount})</span>
                    </div>
                    <h3 className="text-base font-bold text-stone-950 group-hover:text-[#B3541E] transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-stone-500 line-clamp-2">
                      {product.description}
                    </p>
                    <div className="text-xs text-stone-400 pt-1">
                      Crafted in Italy · Goodyear Welted / Artisan Milled
                    </div>
                  </div>
                  <div className="sm:text-right shrink-0 w-full sm:w-auto pt-3 sm:pt-0 border-t sm:border-t-0 border-stone-100 flex sm:flex-col justify-between items-center sm:items-end gap-2">
                    <span className="text-xl font-bold text-stone-950 tabular-nums">
                      ${product.price}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateTo('product-details', product.id);
                      }}
                      className="px-4 py-2 bg-stone-900 text-white hover:bg-stone-800 text-xs font-semibold rounded-lg"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Progressive Load Indicator */}
          <div className="mt-12 text-center pt-8 border-t border-stone-200">
            <p className="text-xs text-stone-500 mb-3">
              Showing {filteredProducts.length} of {products.length} curated masterworks
            </p>
            <div className="w-48 h-1 bg-stone-200 rounded-full mx-auto overflow-hidden mb-4">
              <div
                className="h-full bg-stone-900 rounded-full"
                style={{ width: `${Math.min(100, (filteredProducts.length / products.length) * 100)}%` }}
              />
            </div>
            <button
              onClick={() => {}}
              className="px-6 py-2.5 bg-white border border-stone-300 hover:border-stone-900 text-stone-800 text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
            >
              All Current Atelier Releases Loaded
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
