import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Trash2, Plus, Minus, ArrowRight, ShieldCheck, Tag, ArrowLeft, ShoppingBag } from 'lucide-react';

export const CartPage: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    discountAmount,
    shippingFee,
    cartTotal,
    freeShippingThreshold,
    freeShippingRemaining,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    navigateTo
  } = useShop();

  const [couponCode, setCouponCode] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim()) {
      applyCoupon(couponCode);
      setCouponCode('');
    }
  };

  const freeShippingProgress = Math.min(100, Math.round(((freeShippingThreshold - freeShippingRemaining) / freeShippingThreshold) * 100));

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <div className="max-w-md mx-auto space-y-4">
          <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mx-auto text-stone-400">
            <ShoppingBag className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-extrabold text-stone-900 font-display">Your Shopping Bag is Empty</h2>
          <p className="text-xs text-stone-500">
            You haven't selected any artisanal pieces yet. Explore our handcrafted footwear, wool felt fedoras, and tailored garments.
          </p>
          <div className="pt-4">
            <button
              onClick={() => navigateTo('shop')}
              className="px-6 py-3 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-colors"
            >
              Discover Atelier Catalog
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-stone-200 gap-4">
        <div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs text-stone-500 hover:text-stone-900 flex items-center gap-1.5 mb-2 font-medium"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Continue Shopping</span>
          </button>
          <h1 className="text-3xl font-extrabold text-stone-950 font-display">
            Shopping Bag ({cart.length})
          </h1>
        </div>

        <button
          onClick={clearCart}
          className="text-xs text-stone-400 hover:text-red-600 transition-colors self-start sm:self-auto"
        >
          Clear Entire Bag
        </button>
      </div>

      {/* Free Delivery Milestone Progress */}
      <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs font-semibold text-stone-800 gap-1 mb-2">
          <span>
            {freeShippingRemaining === 0 ? (
              <span className="text-emerald-700 font-bold">
                ✓ Congratulations! You qualify for Complimentary DHL Express Worldwide Shipping.
              </span>
            ) : (
              <span>
                Add <strong className="text-stone-950 font-extrabold">${freeShippingRemaining}</strong> more to unlock Complimentary DHL Express Shipping.
              </span>
            )}
          </span>
          <span className="text-stone-600 font-mono tabular-nums">{freeShippingProgress}% Reached</span>
        </div>
        <div className="w-full h-2 bg-amber-200/60 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#F5B301] transition-all duration-500 rounded-full"
            style={{ width: `${freeShippingProgress}%` }}
          />
        </div>
      </div>

      {/* 2-Column Layout: Items Table (Left) & Order Summary (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        
        {/* Left Column: Itemized List */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="hidden sm:grid grid-cols-12 gap-4 p-4 bg-stone-50 border-b border-stone-200 text-[11px] font-bold uppercase tracking-wider text-stone-500">
            <span className="col-span-6">Product</span>
            <span className="col-span-3 text-center">Quantity</span>
            <span className="col-span-3 text-right">Subtotal</span>
          </div>

          <div className="divide-y divide-stone-100 p-4 sm:p-6">
            {cart.map((item) => (
              <div key={item.id} className="py-6 first:pt-0 last:pb-0 grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                {/* Product Info */}
                <div className="sm:col-span-6 flex gap-4 items-center">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    referrerPolicy="no-referrer"
                    className="w-20 h-20 rounded-xl object-cover bg-stone-100 shrink-0 border border-stone-200"
                  />
                  <div>
                    <span className="text-[10px] uppercase font-bold text-stone-400 block">
                      {item.product.category}
                    </span>
                    <h3 className="text-sm font-bold text-stone-900 leading-snug">
                      {item.product.name}
                    </h3>
                    <div className="text-xs text-stone-500 mt-1 space-x-2">
                      <span>Size: <strong>{item.selectedSize}</strong></span>
                      <span>·</span>
                      <span>Color: <strong>{item.selectedColor}</strong></span>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-[11px] text-stone-400 hover:text-red-500 mt-2 flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>

                {/* Stepper */}
                <div className="sm:col-span-3 flex justify-start sm:justify-center">
                  <div className="flex items-center border border-stone-300 rounded-lg bg-stone-50">
                    <button
                      onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                      className="p-1.5 text-stone-600 hover:text-stone-900 disabled:opacity-30"
                      disabled={item.quantity <= 1}
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs font-bold text-stone-900 tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                      className="p-1.5 text-stone-600 hover:text-stone-900"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Subtotal */}
                <div className="sm:col-span-3 text-left sm:text-right">
                  <span className="text-base font-bold text-stone-950 tabular-nums">
                    ${item.price * item.quantity}
                  </span>
                  <span className="block text-[10px] text-stone-400 tabular-nums">
                    (${item.price} each)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Financial Summary Card */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-stone-200 p-6 sm:p-7 shadow-sm space-y-6">
          <h2 className="text-lg font-bold text-stone-950 font-display pb-3 border-b border-stone-200">
            Order Summary
          </h2>

          {/* Coupon Code Form */}
          <div>
            <label className="text-xs font-semibold text-stone-700 block mb-1.5">
              Promotional Code
            </label>
            {appliedCoupon ? (
              <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs">
                <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
                  <Tag className="w-3.5 h-3.5" />
                  <span><strong>{appliedCoupon}</strong> (20% OFF)</span>
                </div>
                <button
                  onClick={removeCoupon}
                  className="text-stone-400 hover:text-stone-800 font-bold text-xs"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. NIKKISTYLE"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs uppercase placeholder:normal-case focus:outline-none focus:border-stone-900"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-stone-900 text-white font-semibold text-xs rounded-lg hover:bg-stone-800 transition-colors"
                >
                  Apply
                </button>
              </form>
            )}
            <span className="text-[11px] text-stone-400 block mt-1">
              Use code <strong className="text-stone-700 font-mono">NIKKISTYLE</strong> for 20% off footwear & headwear.
            </span>
          </div>

          {/* Detailed Calculations */}
          <div className="space-y-2.5 text-xs text-stone-600 pt-2 border-t border-stone-100">
            <div className="flex justify-between">
              <span>Bag Subtotal</span>
              <span className="font-semibold text-stone-900 tabular-nums">${cartSubtotal}</span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Promotional Discount (20%)</span>
                <span className="font-semibold tabular-nums">-${discountAmount}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span>DHL Express Delivery</span>
              <span className="font-semibold text-stone-900">
                {shippingFee === 0 ? <span className="text-emerald-700 font-bold">COMPLIMENTARY</span> : `$${shippingFee}`}
              </span>
            </div>

            <div className="flex justify-between">
              <span>Estimated Sales Tax</span>
              <span className="font-semibold text-stone-900">Calculated at checkout</span>
            </div>

            <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline text-base font-extrabold text-stone-950">
              <span>Estimated Total</span>
              <span className="text-xl tabular-nums font-display">${cartTotal}</span>
            </div>
          </div>

          {/* Checkout CTA */}
          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigateTo('checkout')}
              className="w-full py-4 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500 pt-1">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Complimentary insured shipping & 30-day returns</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
