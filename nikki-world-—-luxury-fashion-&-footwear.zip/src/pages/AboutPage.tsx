import React from 'react';
import { BRAND_LOGO_SRC, HERO_EDITORIAL_SRC } from '../data/products';
import { useShop } from '../context/ShopContext';
import { ShieldCheck, Compass, Sparkles, MapPin, ArrowRight } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigateTo } = useShop();

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. Hero Brand Story Banner */}
      <section className="bg-stone-950 text-white py-16 sm:py-24 border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs uppercase tracking-widest text-[#F5B301] font-bold block">
              Atelier Heritage & Origin
            </span>
            <h1 className="text-4xl sm:text-5xl font-extrabold font-display text-white leading-tight">
              The Gentleman's Code: Crafting Timeless European Distinction
            </h1>
            <p className="text-base text-stone-300 font-light leading-relaxed">
              Founded on the belief that true luxury is tactile, honest, and unyielding in discipline. NIKKI WORLD was born from a dialogue between the venerable cordwainers of Tuscany and the master milliners of Florence.
            </p>
            <div className="pt-2 flex items-center gap-4 text-xs font-semibold">
              <span className="px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-[#F5B301]">
                Established in Tuscany
              </span>
              <span className="text-stone-400">·</span>
              <span className="text-stone-300">100% Certified Full-Grain Calfskin</span>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/15 aspect-[4/3] bg-stone-900">
              <img
                src={BRAND_LOGO_SRC}
                alt="Nikki World 3D Emblem"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

        </div>
      </section>

      {/* 2. The Emblem & Visual Language */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-5">
            <div className="rounded-2xl overflow-hidden aspect-[4/5] bg-stone-100 shadow-sm border border-stone-200">
              <img
                src={HERO_EDITORIAL_SRC}
                alt="Nikki World Tailoring"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block">
              The Iconography
            </span>
            <h2 className="text-3xl font-extrabold text-stone-950 font-display">
              The Fedora, The Mustache, The Warm Timber
            </h2>
            <p className="text-sm text-stone-600 leading-relaxed">
              Our emblem portrays the modern connoisseur tipping his golden fedora—a gesture of respect to time-tested values, chivalry, and uncompromising sartorial standards.
            </p>
            <p className="text-sm text-stone-600 leading-relaxed">
              Every detail—from the architectural slatted timber backdrops of our flagship boutiques to the golden yellow ribbon accents on our headwear—radiates warmth, gravitas, and refined elegance.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-5 rounded-xl bg-white border border-stone-200 shadow-xs">
                <ShieldCheck className="w-6 h-6 text-[#F5B301] mb-2" />
                <h4 className="text-sm font-bold text-stone-900">Slow Vegetable Tanning</h4>
                <p className="text-xs text-stone-500 mt-1">
                  Using natural barks and chestnut extracts over 60 days to yield a leather that breathes and matures with character.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-white border border-stone-200 shadow-xs">
                <Compass className="w-6 h-6 text-[#F5B301] mb-2" />
                <h4 className="text-sm font-bold text-stone-900">Goodyear Welting</h4>
                <p className="text-xs text-stone-500 mt-1">
                  A continuous 360-degree leather welt stitched through upper and insole, allowing complete rebuilds for generations.
                </p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Flagship Boutiques Showcase */}
      <section className="bg-stone-100/60 py-16 border-y border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block mb-1">
              Private Atelier Network
            </span>
            <h2 className="text-3xl font-extrabold text-stone-950 font-display">
              Our Flagship Destinations
            </h2>
            <p className="text-xs text-stone-500 mt-2">
              Book private fitting appointments or explore our permanent footwear and bespoke headwear collection in person.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Boutique 1: Jodhpur Flagship */}
            <div className="bg-white p-6 rounded-2xl border-2 border-[#F5B301] shadow-md space-y-4">
              <div className="flex items-center gap-2 text-[#B3541E]">
                <MapPin className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Flagship Boutique</span>
              </div>
              <h3 className="text-lg font-bold text-stone-950 font-display">Sardarpura, Jodhpur</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Nikki World Premier Boutique, Sardarpura, Jodhpur, Rajasthan 342003. Housing our full cordwaining gallery, bespoke fedora trunk show, and private fitting lounge.
              </p>
              <div className="text-xs text-stone-500 pt-2 border-t border-stone-100">
                Mon - Sun: 10:30 - 21:00 · Ph: +91 291 261 4432
              </div>
            </div>

            {/* Boutique 2 */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 text-[#B3541E]">
                <MapPin className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Florence Atelier</span>
              </div>
              <h3 className="text-lg font-bold text-stone-950 font-display">Tuscan Partner Guild</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Santa Croce sull'Arno & Florence. Partner cordwainers and master milliners steam-shaping Australian Merino felt.
              </p>
              <div className="text-xs text-stone-500 pt-2 border-t border-stone-100">
                By Invitation & Trunk Show Schedule
              </div>
            </div>

            {/* Boutique 3 */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 text-[#B3541E]">
                <MapPin className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Concierge Worldwide</span>
              </div>
              <h3 className="text-lg font-bold text-stone-950 font-display">Global DHL Express</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Direct insured express dispatch with doorstep delivery, size consultations, and bespoke returns.
              </p>
              <div className="text-xs text-stone-500 pt-2 border-t border-stone-100">
                24/7 Digital Concierge Desk
              </div>
            </div>
          </div>

          <div className="text-center pt-4">
            <button
              onClick={() => navigateTo('contact')}
              className="px-6 py-3 bg-stone-950 hover:bg-stone-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors inline-flex items-center gap-2"
            >
              <span>Schedule Private Boutique Appointment</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
