import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, User, Package, RefreshCw, LogOut, Truck, Check, AlertCircle } from 'lucide-react';

export const CustomerAccountModal: React.FC = () => {
  const {
    isAccountModalOpen,
    setIsAccountModalOpen,
    currentUser,
    logoutUser,
    orders,
    requestReturn,
    returnRequests
  } = useShop();

  const [activeTab, setActiveTab] = useState<'orders' | 'returns' | 'profile'>('orders');
  const [returnOrderId, setReturnOrderId] = useState<string | null>(null);
  const [returnReason, setReturnReason] = useState('');

  if (!isAccountModalOpen) return null;

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (returnOrderId && returnReason.trim()) {
      requestReturn(returnOrderId, returnReason);
      setReturnOrderId(null);
      setReturnReason('');
      setActiveTab('returns');
    }
  };

  const userOrders = orders; // Show user orders

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={() => setIsAccountModalOpen(false)}
        className="absolute inset-0 bg-stone-950/75 backdrop-blur-xs transition-opacity"
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl z-10 border border-stone-200 flex flex-col">
        
        {/* Header */}
        <div className="p-6 bg-stone-950 text-white flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-stone-800 border-2 border-[#F5B301] overflow-hidden flex items-center justify-center text-stone-300 font-bold text-sm">
              {currentUser?.avatar ? (
                <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
              ) : (
                <User className="w-6 h-6 text-[#F5B301]" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white font-display">
                  {currentUser?.name || 'Patron Account'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-[#F5B301] text-stone-950 text-[10px] font-bold">
                  VIP Patron
                </span>
              </div>
              <p className="text-xs text-stone-400">
                {currentUser?.email || 'Registered Client'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                logoutUser();
                setIsAccountModalOpen(false);
              }}
              className="px-3 py-1.5 text-stone-400 hover:text-white hover:bg-stone-800 rounded-lg text-xs flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
            <button
              onClick={() => setIsAccountModalOpen(false)}
              className="text-stone-400 hover:text-white p-1 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex border-b border-stone-200 bg-stone-50 px-6 pt-3 gap-6 text-xs font-semibold text-stone-600">
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
              activeTab === 'orders' ? 'border-stone-950 text-stone-950 font-bold' : 'border-transparent hover:text-stone-900'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>My Commissions & Orders ({userOrders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('returns')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
              activeTab === 'returns' ? 'border-stone-950 text-stone-950 font-bold' : 'border-transparent hover:text-stone-900'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            <span>Bespoke Returns & Exchanges ({returnRequests.length})</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Tab 1: Orders */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              {userOrders.map((order) => (
                <div key={order.id} className="p-4 rounded-xl border border-stone-200 bg-white space-y-3 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
                    <div>
                      <span className="text-xs font-mono font-bold text-stone-900">{order.id}</span>
                      <span className="text-xs text-stone-400 ml-2">Ordered on {order.orderDate}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        order.status === 'Delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : order.status === 'In Transit'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-stone-100 text-stone-800'
                      }`}>
                        {order.status}
                      </span>
                      <span className="text-xs font-bold text-stone-950 tabular-nums">
                        ${order.total}
                      </span>
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="space-y-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-xs">
                        <img
                          src={item.image}
                          alt={item.productName}
                          className="w-12 h-12 object-cover rounded-lg bg-stone-100 border border-stone-200 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-stone-900 truncate">{item.productName}</h4>
                          <span className="text-stone-500 text-[11px]">{item.selectedSize} · {item.selectedColor} (Qty: {item.quantity})</span>
                        </div>
                        <span className="font-bold text-stone-900 tabular-nums">${item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {/* Delivery Info & Return Action */}
                  <div className="pt-3 border-t border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
                    <div className="flex items-center gap-2 text-stone-600 text-[11px]">
                      <Truck className="w-3.5 h-3.5 text-[#F5B301]" />
                      <span>Tracking: <strong className="font-mono text-stone-900">{order.trackingNumber}</strong></span>
                    </div>

                    <div>
                      {order.returnRequested ? (
                        <span className="text-[11px] font-bold px-2 py-1 rounded bg-stone-100 text-stone-700">
                          Return Status: <strong className="text-amber-700">{order.returnStatus}</strong>
                        </span>
                      ) : (
                        <button
                          onClick={() => setReturnOrderId(order.id)}
                          className="text-xs font-semibold text-[#B3541E] hover:underline"
                        >
                          Request Return or Size Exchange
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Return Form Modal Overlay inside account */}
          {returnOrderId && (
            <div className="p-5 rounded-xl bg-amber-50/80 border border-amber-200 space-y-3 text-xs">
              <div className="flex justify-between items-center">
                <h4 className="font-bold text-stone-900">
                  Request Return for Order <span className="font-mono">{returnOrderId}</span>
                </h4>
                <button onClick={() => setReturnOrderId(null)} className="text-stone-400 hover:text-stone-800">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleReturnSubmit} className="space-y-3">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Reason for Return or Exchange *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="e.g. Need half-size larger (exchange for US 9.5), or prefer cognac colorway..."
                    value={returnReason}
                    onChange={(e) => setReturnReason(e.target.value)}
                    className="w-full p-2.5 bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-stone-900 text-white rounded-lg font-semibold hover:bg-stone-800"
                  >
                    Submit Return Request to Atelier
                  </button>
                  <button
                    type="button"
                    onClick={() => setReturnOrderId(null)}
                    className="px-3 py-2 bg-stone-200 text-stone-700 rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Tab 2: Returns Status List */}
          {activeTab === 'returns' && (
            <div className="space-y-4">
              {returnRequests.length === 0 ? (
                <div className="text-center py-8 text-stone-500 text-xs">
                  No active return or exchange requests.
                </div>
              ) : (
                returnRequests.map((ret) => (
                  <div key={ret.id} className="p-4 rounded-xl border border-stone-200 bg-white space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-stone-900">{ret.id} · Order {ret.orderId}</span>
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        ret.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ret.status === 'Refunded'
                          ? 'bg-blue-100 text-blue-800'
                          : ret.status === 'Rejected'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {ret.status}
                      </span>
                    </div>

                    <p className="text-stone-700 font-medium">
                      Item: {ret.productName}
                    </p>
                    <p className="text-stone-500 text-[11px]">
                      Reason: "{ret.reason}"
                    </p>

                    {ret.adminNotes && (
                      <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200 text-[11px] text-stone-700">
                        <strong className="text-stone-900 block font-semibold">Concierge Update:</strong>
                        <span>{ret.adminNotes}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
