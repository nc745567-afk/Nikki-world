import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { BRAND_LOGO_SRC } from '../data/products';
import { X, Lock, Mail, User as UserIcon, Phone, ArrowRight, ShieldCheck } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, loginWithGoogle, registerUser, loginUser } = useShop();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'register') {
      if (name && email) {
        registerUser(name, email, phone);
      }
    } else {
      if (email) {
        loginUser(email);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={() => setIsAuthModalOpen(false)}
        className="absolute inset-0 bg-stone-950/75 backdrop-blur-xs transition-opacity"
      />

      {/* Dialog */}
      <div className="relative bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl z-10 border border-stone-200">
        
        {/* Close Button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 right-4 text-stone-400 hover:text-stone-900 p-1 rounded-lg"
          aria-label="Close authentication modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="p-6 bg-stone-950 text-white text-center relative overflow-hidden">
          <div className="w-12 h-12 rounded-xl overflow-hidden bg-stone-900 border border-amber-600/40 mx-auto mb-3 shadow-md">
            <img src={BRAND_LOGO_SRC} alt="Nikki World" className="w-full h-full object-cover" />
          </div>
          <h2 className="text-xl font-extrabold font-display tracking-tight text-white">
            NIKKI <span className="text-[#F5B301]">WORLD</span>
          </h2>
          <p className="text-xs text-stone-300 mt-1">
            Access your private client portfolio, order tracking, and bespoke requests.
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          
          {/* Sign in with Google (Highlighted Option) */}
          <button
            onClick={loginWithGoogle}
            className="w-full py-3 px-4 bg-white border border-stone-300 hover:border-stone-400 hover:bg-stone-50 text-stone-800 font-semibold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            {/* Google SVG Icon */}
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Divider */}
          <div className="relative flex items-center justify-center">
            <div className="border-t border-stone-200 w-full" />
            <span className="bg-white px-3 text-[11px] uppercase tracking-wider text-stone-400 font-semibold absolute">
              or with email
            </span>
          </div>

          {/* Tab Switcher: Login / Register */}
          <div className="flex rounded-lg bg-stone-100 p-1 text-xs font-semibold">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-1.5 rounded-md transition-all ${
                mode === 'login' ? 'bg-white text-stone-950 shadow-xs' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-1.5 rounded-md transition-all ${
                mode === 'register' ? 'bg-white text-stone-950 shadow-xs' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Register Patron Account
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            {mode === 'register' && (
              <div>
                <label className="block text-stone-700 font-medium mb-1">Full Name *</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    required
                    placeholder="Lord Julian Vance"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-stone-700 font-medium mb-1">Email Address *</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="email"
                  required
                  placeholder="patron@domain.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-stone-700 font-medium mb-1">Phone Number (Courier Alert)</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="tel"
                    placeholder="+1 (555) 019-2831"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-stone-700 font-medium mb-1">Password *</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <span>{mode === 'register' ? 'Complete Registration' : 'Sign In to Nikki World'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Guest / Trust note */}
          <div className="pt-2 text-center text-[11px] text-stone-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Encrypted VIP Patron Credential Vault</span>
          </div>

        </div>

      </div>
    </div>
  );
};
