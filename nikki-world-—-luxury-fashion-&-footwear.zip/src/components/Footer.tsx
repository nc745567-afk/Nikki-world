import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { BRAND_LOGO_SRC } from '../data/products';
import { ShieldCheck, Truck, RefreshCw, Headphones, Check } from 'lucide-react';
import { PageType } from '../types';

export const Footer: React.FC = () => {
  const { navigateTo } = useShop();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const handleNav = (page: PageType) => {
    navigateTo(page);
  };

  return (
    <footer className="bg-[#111111] text-stone-300 pt-16 pb-24 md:pb-16 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Trust Pillars Grid ("The Nikki Standard") */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pb-12 mb-12 border-b border-stone-800/80">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-center shrink-0 text-[#F5B301]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider">Italian Tanneries</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Vegetable-tanned full-grain leather certified in Santa Croce sull'Arno.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-center shrink-0 text-[#F5B301]">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider">Global DHL Express</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Complimentary signature delivery on all orders over $250.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-center shrink-0 text-[#F5B301]">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider">30-Day Bespoke Returns</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Prepaid return courier label included with every handcrafted order.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-center shrink-0 text-[#F5B301]">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider">24/7 VIP Concierge</h4>
              <p className="text-[11px] text-stone-400 mt-0.5">Direct WhatsApp advisory for size, fit, and private atelier visits.</p>
            </div>
          </div>
        </div>

        {/* Main Footer Links & Brand Row */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10 pb-12 border-b border-stone-800/80">
          
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg overflow-hidden bg-stone-900 border border-amber-600/30 flex items-center justify-center shadow-md">
                <img
                  src={BRAND_LOGO_SRC}
                  alt="Nikki World Emblem"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="text-xl font-extrabold text-white font-display tracking-tight">
                  NIKKI <span className="text-[#F5B301]">WORLD</span>
                </span>
                <p className="text-[10px] text-stone-400 uppercase tracking-widest">
                  Haute Footwear & Sartorial House
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-400 leading-relaxed max-w-sm">
              Rooted in the timeless art of Tuscan cordwaining and bespoke millinery. Crafted for the modern connoisseur of fine living with genuine full-grain European hides and hand-shaped wool felt.
            </p>

            {/* Newsletter */}
            <div className="pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-white block mb-2">
                Join the VIP Trunk Show List
              </span>
              {subscribed ? (
                <div className="flex items-center gap-2 text-xs text-emerald-400 bg-stone-900 border border-emerald-800/40 px-3 py-2 rounded-lg">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>Welcome to the Nikki World Circle. Check your inbox for your 20% welcome code.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    required
                    placeholder="Enter your private email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 px-3.5 py-2 bg-stone-900 border border-stone-700 rounded-lg text-xs text-white placeholder:text-stone-500 focus:outline-none focus:border-[#F5B301]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs rounded-lg transition-colors cursor-pointer shrink-0"
                  >
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Column 2: Collections */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Collections</h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Goodyear Welted Oxfords
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Monarch Felt Fedoras
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Tuscan Suede Chelsea Boots
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Neapolitan Wool Tailoring
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Bridle Leather Belts
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Client Care */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Client Care</h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors">
                  Concierge & WhatsApp Direct
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-white transition-colors">
                  Leather Care & Maintenance
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors">
                  Shoe & Hat Size Guide
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('checkout')} className="hover:text-white transition-colors">
                  Shipping & Customs Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors">
                  Book Boutique Appointment
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Boutiques */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Flagship Boutique</h4>
            <div className="space-y-3 text-xs text-stone-400">
              <div>
                <strong className="text-white block font-medium">Jodhpur Flagship</strong>
                <span className="text-[11px] text-stone-300">Sardarpura, Jodhpur, Rajasthan 342003</span>
                <span className="text-[10px] text-stone-400 block mt-0.5">India · Ph: +91 291 261 4432</span>
              </div>
              <div className="pt-1 border-t border-stone-800/80">
                <strong className="text-white block font-medium">Florence Artisan Hub</strong>
                <span className="text-[11px]">Tuscan Tannery Partnership, Florence</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Payment Security */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            © {new Date().getFullYear()} NIKKI WORLD. All rights reserved. Handcrafted in Italy.
          </div>
          
          {/* Payment Trust Badges */}
          <div className="flex flex-wrap items-center gap-2 text-[10px] text-stone-400 font-medium">
            <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">VISA</span>
            <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">MASTERCARD</span>
            <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">AMEX</span>
            <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">APPLE PAY</span>
            <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">CASH ON DELIVERY</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
