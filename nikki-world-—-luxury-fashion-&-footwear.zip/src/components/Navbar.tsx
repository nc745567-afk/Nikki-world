import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { BRAND_LOGO_SRC } from '../data/products';
import { ShoppingBag, Heart, Search, X, Menu, User, ChevronUp } from 'lucide-react';
import { PageType } from '../types';

export const Navbar: React.FC = () => {
  const {
    currentPage,
    navigateTo,
    cartItemCount,
    wishlist,
    setIsCartOpen,
    currentUser,
    setIsAuthModalOpen,
    setIsAccountModalOpen,
    setIsAdminModalOpen,
    isOwnerAuthenticated
  } = useShop();

  const [showBanner, setShowBanner] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleNavClick = (page: PageType) => {
    navigateTo(page);
    setMobileMenuOpen(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('shop');
      setSearchOpen(false);
    }
  };

  return (
    <>
      {/* 1. Announcement Banner (dismissible, <= 40px) */}
      {showBanner && (
        <div className="bg-[#121212] text-stone-200 text-xs py-2 px-3 sm:px-4 border-b border-stone-800">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex-1 text-center font-medium truncate">
              <span>Complimentary DHL Express on orders over $250</span>
              <span className="hidden sm:inline text-stone-400 mx-2">·</span>
              <span className="hidden sm:inline text-[#F5B301] font-semibold">Code NIKKISTYLE for 20% Off</span>
            </div>
            <button
              onClick={() => setShowBanner(false)}
              className="text-stone-400 hover:text-white p-1 rounded transition-colors shrink-0"
              aria-label="Dismiss banner"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 2. Top Bar adhering to strict Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 sm:gap-8">
          
          {/* Zone 1: Single element brand wordmark */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-stone-800 hover:text-stone-950 focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2.5 sm:gap-3 text-left group min-h-[44px]"
            >
              <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-lg overflow-hidden bg-stone-900 border border-amber-600/30 flex items-center justify-center shrink-0 shadow-sm">
                <img
                  src={BRAND_LOGO_SRC}
                  alt="Nikki World Insignia"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1">
                  <span className="text-lg sm:text-xl font-extrabold tracking-tight text-stone-950 font-display">
                    NIKKI <span className="text-[#F5B301]">WORLD</span>
                  </span>
                </div>
                <span className="text-[9px] sm:text-[10px] uppercase tracking-widest text-stone-500 font-medium -mt-1 hidden xs:block">
                  Italian Craftsmanship
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: 4-5 clean single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-7 text-sm font-medium text-stone-700">
            <button
              onClick={() => handleNavClick('home')}
              className={`whitespace-nowrap transition-colors hover:text-stone-950 ${
                currentPage === 'home' ? 'text-stone-950 font-semibold border-b-2 border-[#F5B301] pb-1' : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('shop')}
              className={`whitespace-nowrap transition-colors hover:text-stone-950 ${
                currentPage === 'shop' ? 'text-stone-950 font-semibold border-b-2 border-[#F5B301] pb-1' : ''
              }`}
            >
              Curated Shop
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className={`whitespace-nowrap transition-colors hover:text-stone-950 ${
                currentPage === 'about' ? 'text-stone-950 font-semibold border-b-2 border-[#F5B301] pb-1' : ''
              }`}
            >
              Brand Heritage
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className={`whitespace-nowrap transition-colors hover:text-stone-950 ${
                currentPage === 'contact' ? 'text-stone-950 font-semibold border-b-2 border-[#F5B301] pb-1' : ''
              }`}
            >
              Concierge
            </button>
          </nav>

          {/* Zone 3: Primary action cluster */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            
            {/* Search Trigger */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              aria-label="Search collection"
              className="p-2 text-stone-700 hover:text-stone-950 hover:bg-stone-100 rounded-full transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Trigger */}
            <button
              onClick={() => handleNavClick('shop')}
              aria-label="View wishlist"
              className="relative p-2 text-stone-700 hover:text-stone-950 hover:bg-stone-100 rounded-full transition-colors hidden sm:flex items-center justify-center min-h-[44px] min-w-[44px]"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-stone-900 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* User Patron Sign-in / Account Trigger */}
            {currentUser ? (
              <button
                onClick={() => setIsAccountModalOpen(true)}
                className="flex items-center gap-1.5 p-1.5 sm:px-3 sm:py-1.5 rounded-lg border border-stone-200 hover:border-stone-400 bg-stone-50 transition-colors text-xs font-semibold text-stone-800 min-h-[44px]"
                title="View My Account & Orders"
              >
                <div className="w-6 h-6 rounded-full bg-[#F5B301] text-stone-950 font-bold flex items-center justify-center text-[10px]">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <span className="hidden lg:inline truncate max-w-[90px]">{currentUser.name}</span>
              </button>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-lg border border-stone-300 hover:border-stone-900 text-stone-800 text-xs font-semibold transition-colors min-h-[44px]"
                title="Sign in with Google or Register"
              >
                <User className="w-3.5 h-3.5 text-[#F5B301]" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )}

            {/* Owner Portal Trigger Button */}
            <button
              onClick={() => setIsAdminModalOpen(true)}
              className="hidden md:flex items-center gap-1 px-2.5 py-1.5 bg-stone-950 hover:bg-stone-800 text-white rounded-lg text-xs font-bold transition-all min-h-[44px]"
              title="Open Owner & Executive Portal"
            >
              <ChevronUp className="w-3.5 h-3.5 text-[#F5B301] stroke-[3]" />
              <span>Owner</span>
            </button>

            {/* Shopping Bag Button (Golden Yellow Primary Action) */}
            <button
              onClick={() => setIsCartOpen(true)}
              aria-label="Open shopping bag"
              className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-semibold text-xs sm:text-sm rounded-lg shadow-sm transition-all min-h-[44px]"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Bag</span>
              <span className="w-5 h-5 bg-stone-950 text-white rounded-full text-xs font-bold flex items-center justify-center tabular-nums">
                {cartItemCount}
              </span>
            </button>
          </div>

        </div>

        {/* Expandable Search Drawer */}
        {searchOpen && (
          <div className="bg-stone-50 border-t border-stone-200 px-4 py-3">
            <form onSubmit={handleSearchSubmit} className="max-w-3xl mx-auto flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  placeholder="Search footwear, fedoras, tailoring, calfskin..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white rounded-lg border border-stone-300 text-xs sm:text-sm focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900"
                  autoFocus
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2.5 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors min-h-[44px]"
              >
                Search
              </button>
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="p-2 text-stone-500 hover:text-stone-900 min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-stone-200 px-4 py-4 space-y-2">
            <button
              onClick={() => handleNavClick('home')}
              className="w-full text-left py-2.5 px-3 text-stone-900 font-medium hover:bg-stone-50 rounded-lg min-h-[44px] flex items-center"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('shop')}
              className="w-full text-left py-2.5 px-3 text-stone-900 font-medium hover:bg-stone-50 rounded-lg min-h-[44px] flex items-center"
            >
              Curated Shop
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="w-full text-left py-2.5 px-3 text-stone-900 font-medium hover:bg-stone-50 rounded-lg min-h-[44px] flex items-center"
            >
              Brand Story & Heritage
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="w-full text-left py-2.5 px-3 text-stone-900 font-medium hover:bg-stone-50 rounded-lg min-h-[44px] flex items-center"
            >
              Concierge & Boutiques
            </button>
            
            <div className="pt-2 border-t border-stone-100 space-y-2">
              {currentUser ? (
                <button
                  onClick={() => {
                    setIsAccountModalOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left py-2.5 px-3 bg-stone-50 text-stone-900 font-semibold rounded-lg flex items-center justify-between min-h-[44px]"
                >
                  <span>Patron Account ({currentUser.name})</span>
                  <span className="text-[10px] bg-[#F5B301] text-stone-950 px-2 py-0.5 rounded font-bold">VIP</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setIsAuthModalOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left py-2.5 px-3 bg-stone-100 text-stone-900 font-semibold rounded-lg flex items-center justify-between min-h-[44px]"
                >
                  <span>Sign in with Google / Register</span>
                  <User className="w-4 h-4 text-[#F5B301]" />
                </button>
              )}

              {/* Mobile Owner Portal Trigger */}
              <button
                onClick={() => {
                  setIsAdminModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2.5 px-3 bg-stone-950 text-white font-bold rounded-lg flex items-center justify-between min-h-[44px]"
              >
                <span>Owner Portal</span>
                <ChevronUp className="w-4 h-4 text-[#F5B301] stroke-[3]" />
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
