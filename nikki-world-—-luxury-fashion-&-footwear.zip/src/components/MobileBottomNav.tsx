import React from 'react';
import { useShop } from '../context/ShopContext';
import { Home, Compass, ShoppingBag, Heart, User, ChevronUp } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    currentPage,
    navigateTo,
    cartItemCount,
    wishlist,
    setIsCartOpen,
    currentUser,
    setIsAuthModalOpen,
    setIsAccountModalOpen,
    setIsAdminModalOpen,
    isOwnerAuthenticated
  } = useShop();

  const handleAccountClick = () => {
    if (currentUser) {
      setIsAccountModalOpen(true);
    } else {
      setIsAuthModalOpen(true);
    }
  };

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 px-2 py-1 flex items-center justify-around shadow-2xl"
      style={{ height: '60px' }}
    >
      {/* 1. Home */}
      <button
        onClick={() => navigateTo('home')}
        className={`flex-1 flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors ${
          currentPage === 'home' ? 'text-[#B3541E] font-bold' : 'text-stone-500'
        }`}
      >
        <Home className="w-4 h-4" />
        <span className="text-[10px] leading-none">Home</span>
      </button>

      {/* 2. Shop */}
      <button
        onClick={() => navigateTo('shop')}
        className={`flex-1 flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors ${
          currentPage === 'shop' ? 'text-[#B3541E] font-bold' : 'text-stone-500'
        }`}
      >
        <Compass className="w-4 h-4" />
        <span className="text-[10px] leading-none">Shop</span>
      </button>

      {/* 3. Shopping Bag */}
      <button
        onClick={() => setIsCartOpen(true)}
        className="flex-1 flex flex-col items-center justify-center gap-0.5 min-h-[44px] text-stone-900"
      >
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-[#F5B301] text-stone-950 flex items-center justify-center shadow-xs">
            <ShoppingBag className="w-4 h-4" />
          </div>
          {cartItemCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-stone-900 text-white rounded-full text-[9px] font-bold flex items-center justify-center tabular-nums">
              {cartItemCount}
            </span>
          )}
        </div>
        <span className="text-[9px] font-bold leading-none">Bag</span>
      </button>

      {/* 4. Patron Account / Google Sign-in */}
      <button
        onClick={handleAccountClick}
        className="flex-1 flex flex-col items-center justify-center gap-1 min-h-[44px] text-stone-500"
      >
        <div className="relative">
          <User className={`w-4 h-4 ${currentUser ? 'text-stone-900 font-bold' : 'text-stone-500'}`} />
          {currentUser && (
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full ring-2 ring-white" />
          )}
        </div>
        <span className="text-[10px] leading-none">
          {currentUser ? 'Account' : 'Sign In'}
        </span>
      </button>

      {/* 5. Owner Portal Upward Arrow Quick Trigger */}
      <button
        onClick={() => setIsAdminModalOpen(true)}
        className="flex-1 flex flex-col items-center justify-center gap-1 min-h-[44px] text-stone-900"
        title="Owner Portal"
      >
        <div className="w-7 h-7 rounded-lg bg-stone-950 text-[#F5B301] flex items-center justify-center shadow-xs">
          <ChevronUp className="w-4 h-4 stroke-[3]" />
        </div>
        <span className="text-[9px] font-extrabold uppercase leading-none">Owner</span>
      </button>
    </nav>
  );
};
