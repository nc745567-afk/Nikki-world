import React from 'react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { Heart, Star, Eye, ShoppingBag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { navigateTo, addToCart, toggleWishlist, isWishlisted, openQuickView } = useShop();
  const wishlisted = isWishlisted(product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Default to the first in-stock size and first color
    const availableSize = product.sizes.find(s => s.stock !== 'out_of_stock')?.size || product.sizes[0].size;
    const defaultColor = product.colors[0]?.name || 'Standard';
    addToCart(product, availableSize, defaultColor, 1);
  };

  const handleCardClick = () => {
    navigateTo('product-details', product.id);
  };

  return (
    <div
      onClick={handleCardClick}
      className="group relative bg-white rounded-xl border border-stone-200/80 overflow-hidden flex flex-col transition-all duration-300 hover:shadow-lg hover:-translate-y-1 cursor-pointer"
    >
      {/* Media Container with 4:3 Aspect Ratio */}
      <div className="relative aspect-[4/3] w-full bg-stone-100 overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />

        {/* Badge Overlay */}
        {product.badge && (
          <div className="absolute top-3 left-3">
            <span className="inline-block px-2.5 py-1 text-[11px] font-bold tracking-wider uppercase rounded bg-stone-900 text-white shadow-sm">
              {product.badge}
            </span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-stone-700 hover:text-red-600 hover:bg-white transition-colors shadow-sm"
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              openQuickView(product);
            }}
            className="flex-1 py-2 px-3 bg-white/95 backdrop-blur-sm text-stone-900 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-stone-900 hover:text-white transition-colors shadow-sm"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Quick View</span>
          </button>
          <button
            onClick={handleQuickAdd}
            aria-label="Quick add to bag"
            className="w-9 h-9 bg-[#F5B301] text-stone-950 rounded-lg flex items-center justify-center hover:bg-[#E0A200] transition-colors shadow-sm"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Rating Row */}
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
            <span className="uppercase tracking-wider font-medium text-[11px]">{product.category}</span>
            <div className="flex items-center gap-1 text-stone-700">
              <Star className="w-3 h-3 fill-[#F5B301] text-[#F5B301]" />
              <span className="font-semibold text-xs tabular-nums">{product.rating.toFixed(1)}</span>
              <span className="text-stone-400">({product.reviewsCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3 className="text-stone-900 font-semibold text-sm leading-snug group-hover:text-[#B3541E] transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Subtitle */}
          <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">
            {product.subtitle}
          </p>
        </div>

        {/* Price & Sizes Footprint */}
        <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-base font-bold text-stone-900 tabular-nums">
              ${product.price}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-stone-400 line-through tabular-nums">
                ${product.originalPrice}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-[11px] text-stone-500">
            <span className="text-stone-400">{product.sizes.length} sizes</span>
          </div>
        </div>
      </div>
    </div>
  );
};
