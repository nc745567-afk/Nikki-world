import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Star, ShoppingBag, ArrowRight, Check } from 'lucide-react';

export const QuickViewModal: React.FC = () => {
  const { quickViewProduct, closeQuickView, addToCart, navigateTo } = useShop();

  if (!quickViewProduct) return null;

  const product = quickViewProduct;
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState(
    product.sizes.find(s => s.stock !== 'out_of_stock')?.size || product.sizes[0].size
  );
  const [quantity, setQuantity] = useState(1);

  const handleAdd = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    closeQuickView();
  };

  const handleViewFull = () => {
    closeQuickView();
    navigateTo('product-details', product.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={closeQuickView}
        className="absolute inset-0 bg-stone-950/70 backdrop-blur-xs"
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl z-10 grid grid-cols-1 md:grid-cols-2">
        {/* Close Button */}
        <button
          onClick={closeQuickView}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-700 flex items-center justify-center shadow-sm"
          aria-label="Close dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Media Preview */}
        <div className="relative bg-stone-100 aspect-square md:aspect-auto">
          <img
            src={product.images[0]}
            alt={product.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          {product.badge && (
            <span className="absolute top-3 left-3 px-2.5 py-1 text-[10px] font-bold tracking-wider uppercase rounded bg-stone-900 text-white">
              {product.badge}
            </span>
          )}
        </div>

        {/* Form Content */}
        <div className="p-6 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
              {product.category}
            </span>
            <h3 className="text-lg font-bold text-stone-900 font-display mt-0.5">
              {product.name}
            </h3>
            
            <div className="flex items-center gap-2 mt-1 text-xs">
              <div className="flex items-center text-[#F5B301]">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span className="font-bold text-stone-900 ml-1 tabular-nums">{product.rating.toFixed(1)}</span>
              </div>
              <span className="text-stone-400">·</span>
              <span className="text-stone-500">{product.reviewsCount} reviews</span>
            </div>

            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-xl font-bold text-stone-950 tabular-nums">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-stone-400 line-through tabular-nums">
                  ${product.originalPrice}
                </span>
              )}
            </div>

            {/* Color Swatches */}
            <div className="mt-4">
              <label className="text-xs font-semibold text-stone-700 block mb-1.5">
                Colorway: <span className="font-normal text-stone-500">{selectedColor}</span>
              </label>
              <div className="flex items-center gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color.name)}
                    className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all ${
                      selectedColor === color.name ? 'border-[#F5B301] ring-2 ring-[#F5B301]/30' : 'border-stone-300'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {selectedColor === color.name && (
                      <Check className="w-3.5 h-3.5 text-white drop-shadow-sm" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selector */}
            <div className="mt-4">
              <label className="text-xs font-semibold text-stone-700 block mb-1.5">
                Select Size:
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {product.sizes.map((s) => {
                  const isOut = s.stock === 'out_of_stock';
                  return (
                    <button
                      key={s.size}
                      disabled={isOut}
                      onClick={() => setSelectedSize(s.size)}
                      className={`py-1.5 px-2 text-xs font-medium rounded border text-center transition-colors ${
                        selectedSize === s.size
                          ? 'border-stone-900 bg-stone-900 text-white font-semibold'
                          : isOut
                          ? 'border-stone-200 bg-stone-50 text-stone-300 line-through cursor-not-allowed'
                          : 'border-stone-200 bg-white text-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {s.size.split('/')[0]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="mt-6 pt-4 border-t border-stone-100 space-y-2">
            <button
              onClick={handleAdd}
              className="w-full py-2.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add to Bag (${product.price * quantity})</span>
            </button>
            <button
              onClick={handleViewFull}
              className="w-full py-2 text-stone-600 hover:text-stone-950 text-xs font-medium flex items-center justify-center gap-1 transition-colors"
            >
              <span>View full craftsmanship & specs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
