import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { BRAND_LOGO_SRC } from '../data/products';
import { Product, StaffMember, DiscountCoupon, Order } from '../types';
import {
  X,
  Lock,
  Package,
  Users,
  ShoppingCart,
  Truck,
  RotateCcw,
  Tag,
  Monitor,
  Printer,
  Plus,
  Trash2,
  Check,
  Upload,
  Image as ImageIcon,
  Video,
  LogOut,
  ExternalLink,
  Search,
  Sliders,
  DollarSign
} from 'lucide-react';

export const AdminPortalModal: React.FC = () => {
  const {
    isAdminModalOpen,
    setIsAdminModalOpen,
    isOwnerAuthenticated,
    ownerLogin,
    ownerLogout,
    products,
    addProduct,
    deleteProduct,
    orders,
    updateOrderStatus,
    returnRequests,
    updateReturnStatus,
    staffList,
    addStaff,
    deleteStaff,
    updateStaffStatus,
    coupons,
    addCoupon,
    toggleCoupon,
    deleteCoupon,
    heroConfig,
    updateHeroConfig,
    currentUser
  } = useShop();

  // Login Form States (Credentials: Nemichand / Nemi@1234)
  const [loginId, setLoginId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Admin Tab
  const [activeTab, setActiveTab] = useState<
    'overview' | 'orders' | 'inventory' | 'customers' | 'staff' | 'shipments' | 'returns' | 'discounts' | 'homescreen'
  >('overview');

  // Printable Bill & Delivery Slip State
  const [selectedOrderForBill, setSelectedOrderForBill] = useState<Order | null>(null);

  // Add Catalogue / Product Form State
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductSubtitle, setNewProductSubtitle] = useState('');
  const [newProductCategory, setNewProductCategory] = useState('Footwear');
  const [customCategory, setCustomCategory] = useState('');
  const [newProductGender, setNewProductGender] = useState<'Men' | 'Women' | 'Unisex'>('Men');
  const [newProductPrice, setNewProductPrice] = useState(295);
  const [newProductOriginalPrice, setNewProductOriginalPrice] = useState(350);
  const [newProductBadge, setNewProductBadge] = useState('NEW SEASON');
  const [newProductDescription, setNewProductDescription] = useState('Handcrafted Italian calfskin with artisanal burnishing and Goodyear welted sole.');
  const [newProductImage, setNewProductImage] = useState('/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg');

  // Add Staff State
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<StaffMember['role']>('Master Cordwainer');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffPhone, setNewStaffPhone] = useState('');
  const [newStaffBoutique, setNewStaffBoutique] = useState('Jodhpur Flagship (Sardarpura)');

  // Add Coupon State
  const [showAddCouponModal, setShowAddCouponModal] = useState(false);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponPercent, setNewCouponPercent] = useState(15);
  const [newCouponDesc, setNewCouponDesc] = useState('');
  const [newCouponMin, setNewCouponMin] = useState(150);

  // Return note state
  const [adminReturnNote, setAdminReturnNote] = useState('');

  if (!isAdminModalOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const success = ownerLogin(loginId, loginPassword);
    if (!success) {
      setLoginError('Invalid Owner ID or Password. Please check your credentials.');
    }
  };

  // Handle Photo File Upload with DataURL preview
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setNewProductImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCategory = newProductCategory === 'Custom' ? (customCategory || 'Artisanal') : newProductCategory;

    const newProd: Product = {
      id: `nw-${Date.now()}`,
      name: newProductName || 'Bespoke Atelier Piece',
      subtitle: newProductSubtitle || 'Handcrafted European Fine Goods',
      category: finalCategory as any,
      gender: newProductGender,
      price: Number(newProductPrice),
      originalPrice: Number(newProductOriginalPrice),
      rating: 5.0,
      reviewsCount: 1,
      images: [newProductImage],
      colors: [
        { name: 'Tuscan Cognac', hex: '#8B4513', inStock: true },
        { name: 'Obsidian Noir', hex: '#1C1C1C', inStock: true }
      ],
      sizes: [
        { size: 'US 8 / EU 41', stock: 'in_stock' },
        { size: 'US 9 / EU 42.5', stock: 'in_stock' },
        { size: 'US 10 / EU 44', stock: 'in_stock' }
      ],
      badge: (newProductBadge as any) || 'NEW SEASON',
      isTrending: true,
      isBestseller: true,
      description: newProductDescription,
      features: [
        'Goodyear 360° welted sole for lifetime resoleability',
        'Certified Tuscan full-grain vegetable-tanned leather',
        'Hand-burnished by master cordwainers in Italy'
      ],
      specs: {
        craftsmanship: 'Produced in small artisanal batches in Florence.',
        materials: '100% full-grain calfskin, silk and cupro lining.',
        fitRecommendation: 'True to European luxury dress standards.',
        shipping: 'Complimentary DHL Express worldwide shipping.'
      },
      sku: `NW-CAT-${Math.floor(1000 + Math.random() * 9000)}`
    };

    addProduct(newProd);
    setShowAddProductModal(false);
    // Reset form
    setNewProductName('');
    setNewProductSubtitle('');
  };

  const handleCreateStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (newStaffName && newStaffEmail) {
      addStaff({
        name: newStaffName,
        role: newStaffRole,
        email: newStaffEmail,
        phone: newStaffPhone || '+39 02 8901 0000',
        boutique: newStaffBoutique,
        status: 'Active'
      });
      setShowAddStaffModal(false);
      setNewStaffName('');
      setNewStaffEmail('');
    }
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCouponCode) {
      addCoupon({
        code: newCouponCode.trim().toUpperCase(),
        discountPercent: Number(newCouponPercent),
        description: newCouponDesc || `${newCouponPercent}% Exclusive Discount`,
        minSpend: Number(newCouponMin),
        usageCount: 0,
        isActive: true,
        expiresOn: '2027-12-31'
      });
      setShowAddCouponModal(false);
      setNewCouponCode('');
    }
  };

  // Overview metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const activeOrdersCount = orders.filter((o) => o.status !== 'Delivered' && o.status !== 'Cancelled').length;
  const pendingReturnsCount = returnRequests.filter((r) => r.status === 'Pending').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4">
      {/* Backdrop */}
      <div
        onClick={() => setIsAdminModalOpen(false)}
        className="absolute inset-0 bg-stone-950/80 backdrop-blur-xs transition-opacity"
      />

      {/* Main Container */}
      <div className="relative bg-white rounded-2xl max-w-6xl w-full h-[92vh] overflow-hidden shadow-2xl z-10 border border-stone-200 flex flex-col">
        
        {/* If Not Authenticated: Secure Owner Login Screen */}
        {!isOwnerAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-6 bg-stone-900 text-white">
            <div className="max-w-md w-full bg-stone-950 p-8 rounded-2xl border border-stone-800 shadow-2xl space-y-6 text-center">
              <div className="w-16 h-16 rounded-2xl overflow-hidden bg-stone-900 border-2 border-[#F5B301] mx-auto shadow-md">
                <img src={BRAND_LOGO_SRC} alt="Nikki World" className="w-full h-full object-cover" />
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#F5B301]">
                  Executive Administration
                </span>
                <h2 className="text-2xl font-extrabold font-display text-white mt-1">
                  Owner & Executive Portal
                </h2>
                <p className="text-xs text-stone-400 mt-1">
                  Restricted to brand owners, inventory master, and concierge supervisors.
                </p>
              </div>

              {loginError && (
                <div className="p-3 bg-red-950/60 border border-red-800 rounded-lg text-xs text-red-300">
                  {loginError}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4 text-xs text-left">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Owner User ID</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter Owner ID"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-stone-900 border border-stone-700 rounded-lg text-white focus:outline-none focus:border-[#F5B301]"
                  />
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Owner Password</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-stone-900 border border-stone-700 rounded-lg text-white focus:outline-none focus:border-[#F5B301]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Authenticate & Access Portal</span>
                  </button>
                </div>
              </form>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdminModalOpen(false)}
                  className="text-xs text-stone-400 hover:text-white"
                >
                  Return to Storefront
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Authenticated Owner Dashboard */
          <>
            {/* Top Navigation Bar of Admin Portal */}
            <div className="bg-stone-950 text-white px-6 py-4 flex items-center justify-between border-b border-stone-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl overflow-hidden bg-stone-900 border border-[#F5B301] shrink-0">
                  <img src={BRAND_LOGO_SRC} alt="Logo" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-extrabold font-display tracking-tight text-white">
                      NIKKI WORLD
                    </span>
                    <span className="px-2 py-0.5 rounded bg-[#F5B301] text-stone-950 font-extrabold text-[10px] uppercase">
                      Owner Portal
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400">
                    Logged in as: <strong className="text-amber-300">Nemichand</strong> (Global Director)
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={ownerLogout}
                  className="px-3 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Logout</span>
                </button>
                <button
                  onClick={() => setIsAdminModalOpen(false)}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-900"
                  aria-label="Close portal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sub-Nav Tabs Strip */}
            <div className="bg-stone-900 text-stone-300 px-6 flex items-center gap-2 overflow-x-auto scrollbar-none border-b border-stone-800 text-xs shrink-0">
              {[
                { id: 'overview', label: 'Overview', icon: Monitor },
                { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingCart },
                { id: 'inventory', label: `Inventory & Add Catalogue (${products.length})`, icon: Package },
                { id: 'customers', label: 'Customers', icon: Users },
                { id: 'staff', label: `Staff (${staffList.length})`, icon: Users },
                { id: 'shipments', label: 'Shipments (DHL)', icon: Truck },
                { id: 'returns', label: `Returns (${returnRequests.length})`, icon: RotateCcw },
                { id: 'discounts', label: `Discounts & Promo (${coupons.length})`, icon: Tag },
                { id: 'homescreen', label: 'Home Screen Media', icon: Video }
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`py-3 px-3 flex items-center gap-2 whitespace-nowrap font-medium border-b-2 transition-all cursor-pointer ${
                      isActive
                        ? 'border-[#F5B301] text-[#F5B301] font-bold bg-stone-950/40'
                        : 'border-transparent text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab Content Body */}
            <div className="flex-1 overflow-y-auto p-6 bg-stone-50">
              
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs">
                      <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">Total Revenue</span>
                      <span className="text-2xl font-extrabold text-stone-900 font-display tabular-nums mt-1 block">
                        ${totalRevenue.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">↑ 24% vs last cycle</span>
                    </div>

                    <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs">
                      <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">Active Orders</span>
                      <span className="text-2xl font-extrabold text-stone-900 font-display tabular-nums mt-1 block">
                        {activeOrdersCount}
                      </span>
                      <span className="text-[11px] text-stone-500 mt-1 block">Via DHL Express</span>
                    </div>

                    <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs">
                      <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">Live Catalogue</span>
                      <span className="text-2xl font-extrabold text-stone-900 font-display tabular-nums mt-1 block">
                        {products.length} Items
                      </span>
                      <span className="text-[11px] text-stone-500 mt-1 block">Instant sync active</span>
                    </div>

                    <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs">
                      <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">Pending Returns</span>
                      <span className="text-2xl font-extrabold text-amber-600 font-display tabular-nums mt-1 block">
                        {pendingReturnsCount}
                      </span>
                      <span className="text-[11px] text-stone-500 mt-1 block">Requires concierge review</span>
                    </div>
                  </div>

                  {/* Quick Action Strip */}
                  <div className="p-4 bg-white rounded-xl border border-stone-200 flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <h4 className="text-sm font-bold text-stone-900">Catalogue & Store Status</h4>
                      <p className="text-xs text-stone-500">Nikki World storefront is currently live and synchronized.</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setActiveTab('inventory');
                          setShowAddProductModal(true);
                        }}
                        className="px-4 py-2 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add New Catalogue Piece</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ORDERS (WITH PRINTABLE BILLS & DELIVERY SLIPS) */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
                    <div>
                      <h3 className="text-base font-bold text-stone-900 font-display">Client Orders & Commissions</h3>
                      <p className="text-xs text-stone-500">Manage fulfillment, update status, and generate official printable bills & delivery slips.</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider text-[11px] font-bold">
                        <tr>
                          <th className="p-3">Order #</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Items</th>
                          <th className="p-3">Total</th>
                          <th className="p-3">Fulfillment Status</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {orders.map((ord) => (
                          <tr key={ord.id} className="hover:bg-stone-50/70 transition-colors">
                            <td className="p-3 font-mono font-bold text-stone-900">{ord.id}</td>
                            <td className="p-3">
                              <span className="font-semibold text-stone-900 block">{ord.customerName}</span>
                              <span className="text-[11px] text-stone-400">{ord.customerEmail}</span>
                            </td>
                            <td className="p-3 text-stone-600">
                              {ord.items.map((i) => `${i.productName} (x${i.quantity})`).join(', ')}
                            </td>
                            <td className="p-3 font-bold text-stone-900 tabular-nums">${ord.total}</td>
                            <td className="p-3">
                              <select
                                value={ord.status}
                                onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                                className="px-2 py-1 bg-stone-100 border border-stone-300 rounded text-xs font-semibold text-stone-800"
                              >
                                <option value="Pending">Pending</option>
                                <option value="Confirmed">Confirmed</option>
                                <option value="Dispatched">Dispatched</option>
                                <option value="In Transit">In Transit</option>
                                <option value="Delivered">Delivered</option>
                                <option value="Cancelled">Cancelled</option>
                              </select>
                            </td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => setSelectedOrderForBill(ord)}
                                className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
                              >
                                <Printer className="w-3.5 h-3.5 text-[#F5B301]" />
                                <span>Print Bill & Slip</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: INVENTORY WITH ADD CATALOGUE (INSTANT SYNC) */}
              {activeTab === 'inventory' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
                    <div>
                      <h3 className="text-base font-bold text-stone-900 font-display">
                        Inventory & Live Catalogue ({products.length} Styles)
                      </h3>
                      <p className="text-xs text-stone-500">
                        Add new styles with custom photos & categories. Changes immediately sync to live customer views.
                      </p>
                    </div>

                    <button
                      onClick={() => setShowAddProductModal(true)}
                      className="px-4 py-2.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs rounded-xl flex items-center gap-2 shadow-sm transition-all cursor-pointer self-start sm:self-auto"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Catalogue Piece (+ Photo)</span>
                    </button>
                  </div>

                  {/* Add Catalogue Form Modal Overlay */}
                  {showAddProductModal && (
                    <div className="bg-white p-6 rounded-2xl border-2 border-[#F5B301] shadow-lg space-y-4">
                      <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                        <h4 className="font-bold text-stone-950 font-display">
                          Create New Catalogue Piece (Instant Live Sync)
                        </h4>
                        <button onClick={() => setShowAddProductModal(false)} className="text-stone-400 hover:text-stone-900">
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      <form onSubmit={handleCreateProduct} className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Product Title *</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. The Venetian Velvet Loafer"
                            value={newProductName}
                            onChange={(e) => setNewProductName(e.target.value)}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Subtitle / Material Details</label>
                          <input
                            type="text"
                            placeholder="e.g. Midnight Silk Velvet with Grosgrain Trim"
                            value={newProductSubtitle}
                            onChange={(e) => setNewProductSubtitle(e.target.value)}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Category</label>
                          <select
                            value={newProductCategory}
                            onChange={(e) => setNewProductCategory(e.target.value)}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          >
                            <option value="Footwear">Footwear</option>
                            <option value="Hats">Fedoras & Hats</option>
                            <option value="Tailoring">Tailoring</option>
                            <option value="Women">Women's Outerwear</option>
                            <option value="Accessories">Accessories</option>
                            <option value="Custom">Custom / New Category...</option>
                          </select>
                        </div>

                        {newProductCategory === 'Custom' && (
                          <div>
                            <label className="block text-stone-700 font-semibold mb-1">Custom Category Name</label>
                            <input
                              type="text"
                              placeholder="e.g. Leather Luggage"
                              value={customCategory}
                              onChange={(e) => setCustomCategory(e.target.value)}
                              className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                            />
                          </div>
                        )}

                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Price (USD) *</label>
                          <input
                            type="number"
                            required
                            value={newProductPrice}
                            onChange={(e) => setNewProductPrice(Number(e.target.value))}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Original MSRP (Optional)</label>
                          <input
                            type="number"
                            value={newProductOriginalPrice}
                            onChange={(e) => setNewProductOriginalPrice(Number(e.target.value))}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-stone-700 font-semibold mb-1">Badge Tag</label>
                          <select
                            value={newProductBadge}
                            onChange={(e) => setNewProductBadge(e.target.value)}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          >
                            <option value="NEW SEASON">NEW SEASON</option>
                            <option value="BESTSELLER">BESTSELLER</option>
                            <option value="LIMITED RUN">LIMITED RUN</option>
                            <option value="ARTISANAL">ARTISANAL</option>
                            <option value="20% OFF">20% OFF</option>
                          </select>
                        </div>

                        {/* Photo Option */}
                        <div className="sm:col-span-2 p-3 bg-stone-50 rounded-xl border border-stone-200">
                          <label className="block text-stone-800 font-bold mb-1.5">
                            Product Photo (Upload File or Select Preset)
                          </label>
                          <div className="flex flex-col sm:flex-row items-center gap-4">
                            <img
                              src={newProductImage}
                              alt="Preview"
                              className="w-20 h-20 object-cover rounded-lg border border-stone-300 bg-white shrink-0"
                            />
                            <div className="flex-1 space-y-2 w-full">
                              <label className="px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold cursor-pointer inline-flex items-center gap-2 hover:bg-stone-800">
                                <Upload className="w-3.5 h-3.5" />
                                <span>Upload Image File from Device</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={handlePhotoUpload}
                                  className="hidden"
                                />
                              </label>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setNewProductImage('/src/assets/images/product_oxford_leather_shoes_1794474234392.jpg')}
                                  className="text-[11px] text-stone-600 underline"
                                >
                                  Tuscan Shoes
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setNewProductImage('/src/assets/images/product_fedora_hat_1794474234880.jpg')}
                                  className="text-[11px] text-stone-600 underline"
                                >
                                  Fedora Hat
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setNewProductImage('/src/assets/images/product_bespoke_suit_1794474235301.jpg')}
                                  className="text-[11px] text-stone-600 underline"
                                >
                                  Wool Blazer
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-stone-700 font-semibold mb-1">Description</label>
                          <textarea
                            rows={2}
                            value={newProductDescription}
                            onChange={(e) => setNewProductDescription(e.target.value)}
                            className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:border-stone-900"
                          />
                        </div>

                        <div className="sm:col-span-2 flex gap-3 pt-2">
                          <button
                            type="submit"
                            className="px-6 py-2.5 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all cursor-pointer"
                          >
                            Save & Sync Live with Web
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowAddProductModal(false)}
                            className="px-4 py-2.5 bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  {/* Products Table */}
                  <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider text-[11px] font-bold">
                        <tr>
                          <th className="p-3">Piece</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Price</th>
                          <th className="p-3">Badge</th>
                          <th className="p-3">Sizes Available</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {products.map((p) => (
                          <tr key={p.id} className="hover:bg-stone-50/70 transition-colors">
                            <td className="p-3 flex items-center gap-3">
                              <img
                                src={p.images[0]}
                                alt={p.name}
                                className="w-12 h-12 object-cover rounded-lg bg-stone-100 border border-stone-200 shrink-0"
                              />
                              <div>
                                <span className="font-bold text-stone-900 block">{p.name}</span>
                                <span className="text-[11px] text-stone-400">{p.sku}</span>
                              </div>
                            </td>
                            <td className="p-3 text-stone-600 font-medium">{p.category}</td>
                            <td className="p-3 font-bold text-stone-900 tabular-nums">${p.price}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 bg-stone-100 text-stone-800 rounded text-[10px] font-bold">
                                {p.badge || 'Standard'}
                              </span>
                            </td>
                            <td className="p-3 text-stone-500 text-[11px]">
                              {p.sizes.length} sizes in stock
                            </td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => deleteProduct(p.id)}
                                className="p-1.5 text-stone-400 hover:text-red-600 rounded transition-colors"
                                title="Remove piece from catalogue"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 4: CUSTOMERS */}
              {activeTab === 'customers' && (
                <div className="space-y-4">
                  <div className="pb-2">
                    <h3 className="text-base font-bold text-stone-900 font-display">Registered VIP Patrons & Clients</h3>
                    <p className="text-xs text-stone-500">View patron contact details, commission count, and verified accounts.</p>
                  </div>

                  <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider text-[11px] font-bold">
                        <tr>
                          <th className="p-3">Patron Name</th>
                          <th className="p-3">Email Address</th>
                          <th className="p-3">Phone</th>
                          <th className="p-3">Account Tier</th>
                          <th className="p-3">Total Commissions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {currentUser ? (
                          <tr className="hover:bg-stone-50/70">
                            <td className="p-3 font-bold text-stone-900">
                              {currentUser.name}
                            </td>
                            <td className="p-3 text-stone-600">{currentUser.email}</td>
                            <td className="p-3 text-stone-600">{currentUser.phone || '—'}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded bg-[#F5B301] text-stone-950 font-bold text-[10px]">
                                VIP Patron ({currentUser.authProvider.toUpperCase()})
                              </span>
                            </td>
                            <td className="p-3 font-semibold text-stone-900">
                              {orders.filter(o => o.customerEmail === currentUser.email).length} Commissions
                            </td>
                          </tr>
                        ) : null}

                        {orders.map((ord) => (
                          ord.customerEmail !== currentUser?.email ? (
                            <tr key={ord.id} className="hover:bg-stone-50/70">
                              <td className="p-3 font-bold text-stone-900">{ord.customerName}</td>
                              <td className="p-3 text-stone-600">{ord.customerEmail}</td>
                              <td className="p-3 text-stone-600">{ord.customerPhone}</td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded bg-stone-100 text-stone-800 font-bold text-[10px]">
                                  Client
                                </span>
                              </td>
                              <td className="p-3 font-semibold text-stone-900">1 Commission (${ord.total})</td>
                            </tr>
                          ) : null
                        ))}

                        {!currentUser && orders.length === 0 && (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-stone-400 text-xs">
                              No customer accounts or commissions recorded yet. New customer registrations and placed orders will appear here automatically.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 5: STAFF MANAGEMENT */}
              {activeTab === 'staff' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
                    <div>
                      <h3 className="text-base font-bold text-stone-900 font-display">Staff & Master Cordwainers</h3>
                      <p className="text-xs text-stone-500">Manage atelier craftsmen, stylists, concierge leads, and boutique shifts.</p>
                    </div>
                    <button
                      onClick={() => setShowAddStaffModal(true)}
                      className="px-3.5 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 hover:bg-stone-800"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Staff Member</span>
                    </button>
                  </div>

                  {showAddStaffModal && (
                    <div className="bg-white p-5 rounded-xl border border-stone-300 shadow-sm space-y-3 text-xs">
                      <h4 className="font-bold text-stone-900">Register Staff Member</h4>
                      <form onSubmit={handleCreateStaff} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="text"
                          required
                          placeholder="Full Name"
                          value={newStaffName}
                          onChange={(e) => setNewStaffName(e.target.value)}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <select
                          value={newStaffRole}
                          onChange={(e) => setNewStaffRole(e.target.value as any)}
                          className="p-2 border border-stone-300 rounded"
                        >
                          <option value="Master Cordwainer">Master Cordwainer</option>
                          <option value="Inventory Lead">Inventory Lead</option>
                          <option value="Concierge Manager">Concierge Manager</option>
                          <option value="Boutique Stylist">Boutique Stylist</option>
                          <option value="Logistics Lead">Logistics Lead</option>
                        </select>
                        <input
                          type="email"
                          required
                          placeholder="Email Address"
                          value={newStaffEmail}
                          onChange={(e) => setNewStaffEmail(e.target.value)}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <input
                          type="tel"
                          placeholder="Phone Number"
                          value={newStaffPhone}
                          onChange={(e) => setNewStaffPhone(e.target.value)}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <div className="sm:col-span-2 flex gap-2 pt-1">
                          <button type="submit" className="px-4 py-2 bg-[#F5B301] text-stone-950 font-bold rounded">
                            Confirm Staff
                          </button>
                          <button type="button" onClick={() => setShowAddStaffModal(false)} className="px-3 py-2 bg-stone-200 text-stone-700 rounded">
                            Cancel
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {staffList.map((st) => (
                      <div key={st.id} className="p-4 bg-white rounded-xl border border-stone-200 flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-stone-900 text-sm">{st.name}</h4>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-700">
                              {st.role}
                            </span>
                          </div>
                          <p className="text-xs text-stone-500 mt-1">{st.boutique}</p>
                          <p className="text-[11px] text-stone-400">{st.email} · {st.phone}</p>
                        </div>
                        <div className="text-right space-y-1">
                          <button
                            onClick={() => updateStaffStatus(st.id, st.status === 'Active' ? 'Shift Active' : 'Active')}
                            className={`px-2 py-1 rounded text-[10px] font-bold block ${
                              st.status === 'Shift Active' ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 text-stone-600'
                            }`}
                          >
                            {st.status}
                          </button>
                          {st.id !== 'st-1' && (
                            <button
                              onClick={() => deleteStaff(st.id)}
                              className="text-[10px] text-stone-400 hover:text-red-500"
                            >
                              Remove
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: SHIPMENT MANAGEMENT */}
              {activeTab === 'shipments' && (
                <div className="space-y-4">
                  <div className="pb-2">
                    <h3 className="text-base font-bold text-stone-900 font-display">DHL Express Worldwide Dispatch</h3>
                    <p className="text-xs text-stone-500">Real-time airway bill tracking and courier carrier dispatch integration.</p>
                  </div>

                  <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider text-[11px] font-bold">
                        <tr>
                          <th className="p-3">Tracking Number</th>
                          <th className="p-3">Order Ref</th>
                          <th className="p-3">Carrier</th>
                          <th className="p-3">Destination</th>
                          <th className="p-3">Status</th>
                          <th className="p-3">Estimated Arrival</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {orders.map((o) => (
                          <tr key={o.id} className="hover:bg-stone-50/70">
                            <td className="p-3 font-mono font-bold text-stone-900">{o.trackingNumber}</td>
                            <td className="p-3 font-mono">{o.id}</td>
                            <td className="p-3 font-semibold text-stone-700">DHL Express Air</td>
                            <td className="p-3 text-stone-600">{o.city}, {o.country}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                o.status === 'Delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {o.status}
                              </span>
                            </td>
                            <td className="p-3 text-stone-500">{o.deliveryDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 7: RETURN REQUESTS WITH INSTANT CUSTOMER ACCOUNT UPDATE */}
              {activeTab === 'returns' && (
                <div className="space-y-4">
                  <div className="pb-2">
                    <h3 className="text-base font-bold text-stone-900 font-display">
                      Bespoke Return & Size Exchange Requests ({returnRequests.length})
                    </h3>
                    <p className="text-xs text-stone-500">
                      Decisions immediately reflect in the patron's account and trigger automated return labels.
                    </p>
                  </div>

                  <div className="space-y-4">
                    {returnRequests.map((ret) => (
                      <div key={ret.id} className="p-5 bg-white rounded-xl border border-stone-200 space-y-3 shadow-xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
                          <div>
                            <span className="font-mono font-bold text-stone-900 text-sm">{ret.id} · Order {ret.orderId}</span>
                            <span className="text-xs text-stone-400 ml-3">Requested on {ret.requestDate}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs text-stone-500">Current Status:</span>
                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                              ret.status === 'Approved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : ret.status === 'Refunded'
                                ? 'bg-blue-100 text-blue-800'
                                : ret.status === 'Rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {ret.status}
                            </span>
                          </div>
                        </div>

                        <div className="text-xs space-y-1">
                          <p><strong>Customer:</strong> {ret.customerName} ({ret.customerEmail})</p>
                          <p><strong>Piece:</strong> {ret.productName}</p>
                          <p className="text-stone-700 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                            <strong>Patron Reason:</strong> "{ret.reason}"
                          </p>
                          {ret.adminNotes && (
                            <p className="text-xs text-emerald-700 font-medium">
                              <strong>Last Concierge Note:</strong> {ret.adminNotes}
                            </p>
                          )}
                        </div>

                        {/* Admin Action Buttons (Instant Sync with Customer Account) */}
                        <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => updateReturnStatus(ret.id, 'Approved', 'Prepaid DHL express return label sent to your email. Replacement size reserved.')}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
                          >
                            ✓ Approve Return & Send Slip
                          </button>

                          <button
                            onClick={() => updateReturnStatus(ret.id, 'Refunded', 'Bespoke refund issued to original payment gateway.')}
                            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors"
                          >
                            $ Issue Refund to Patron
                          </button>

                          <button
                            onClick={() => updateReturnStatus(ret.id, 'Rejected', 'Item does not meet 30-day unworn condition requirements.')}
                            className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg text-xs font-semibold transition-colors"
                          >
                            Reject Request
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 8: DISCOUNTS & PROMOTIONAL COUPONS */}
              {activeTab === 'discounts' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
                    <div>
                      <h3 className="text-base font-bold text-stone-900 font-display">Promo & Discount Codes</h3>
                      <p className="text-xs text-stone-500">Configure promotional campaigns and coupon codes for customers.</p>
                    </div>

                    <button
                      onClick={() => setShowAddCouponModal(true)}
                      className="px-3.5 py-2 bg-[#F5B301] text-stone-950 font-bold rounded-lg text-xs flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create New Coupon</span>
                    </button>
                  </div>

                  {showAddCouponModal && (
                    <div className="bg-white p-5 rounded-xl border border-stone-300 shadow-sm space-y-3 text-xs">
                      <h4 className="font-bold text-stone-900">Create New Promo Code</h4>
                      <form onSubmit={handleCreateCoupon} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="text"
                          required
                          placeholder="Coupon Code (e.g. LUXURY25)"
                          value={newCouponCode}
                          onChange={(e) => setNewCouponCode(e.target.value)}
                          className="p-2 border border-stone-300 rounded uppercase"
                        />
                        <input
                          type="number"
                          required
                          placeholder="Discount Percentage (e.g. 25)"
                          value={newCouponPercent}
                          onChange={(e) => setNewCouponPercent(Number(e.target.value))}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <input
                          type="text"
                          placeholder="Description (e.g. 25% Off Tailoring)"
                          value={newCouponDesc}
                          onChange={(e) => setNewCouponDesc(e.target.value)}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <input
                          type="number"
                          placeholder="Minimum Spend (e.g. 200)"
                          value={newCouponMin}
                          onChange={(e) => setNewCouponMin(Number(e.target.value))}
                          className="p-2 border border-stone-300 rounded"
                        />
                        <div className="sm:col-span-2 flex gap-2">
                          <button type="submit" className="px-4 py-2 bg-stone-900 text-white font-bold rounded">
                            Save Coupon
                          </button>
                          <button type="button" onClick={() => setShowAddCouponModal(false)} className="px-3 py-2 bg-stone-200 text-stone-700 rounded">
                            Cancel
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {coupons.map((c) => (
                      <div key={c.code} className="p-4 bg-white rounded-xl border border-stone-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-extrabold text-sm text-stone-950">{c.code}</span>
                          <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-xs">
                            {c.discountPercent}% OFF
                          </span>
                        </div>
                        <p className="text-xs text-stone-500">{c.description}</p>
                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400">
                          <span>Min Spend: ${c.minSpend}</span>
                          <span>Used: {c.usageCount} times</span>
                        </div>
                        <div className="pt-2 flex justify-between items-center">
                          <button
                            onClick={() => toggleCoupon(c.code)}
                            className={`text-xs font-semibold ${c.isActive ? 'text-emerald-700' : 'text-stone-400'}`}
                          >
                            {c.isActive ? '● Active' : '○ Disabled'}
                          </button>
                          <button
                            onClick={() => deleteCoupon(c.code)}
                            className="text-stone-400 hover:text-red-500"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 9: HOME SCREEN CUSTOMIZATION (VIDEO OR IMAGE OPTION) */}
              {activeTab === 'homescreen' && (
                <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-6">
                  <div>
                    <h3 className="text-base font-bold text-stone-900 font-display">
                      Home Screen Presentation & Media Customizer
                    </h3>
                    <p className="text-xs text-stone-500">
                      Switch the hero between cinematic video background or high-fashion editorial imagery, and edit headlines.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
                    {/* Media Type Switcher */}
                    <div className="sm:col-span-2 space-y-2">
                      <label className="block text-stone-800 font-bold">Hero Media Format</label>
                      <div className="flex gap-4">
                        <button
                          type="button"
                          onClick={() => updateHeroConfig({ mediaType: 'image' })}
                          className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-2 font-semibold transition-all ${
                            heroConfig.mediaType === 'image'
                              ? 'border-stone-950 bg-stone-950 text-white shadow-sm'
                              : 'border-stone-300 bg-stone-50 text-stone-700'
                          }`}
                        >
                          <ImageIcon className="w-4 h-4 text-[#F5B301]" />
                          <span>High-Fashion Photography (Image)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => updateHeroConfig({ mediaType: 'video' })}
                          className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-2 font-semibold transition-all ${
                            heroConfig.mediaType === 'video'
                              ? 'border-stone-950 bg-stone-950 text-white shadow-sm'
                              : 'border-stone-300 bg-stone-50 text-stone-700'
                          }`}
                        >
                          <Video className="w-4 h-4 text-[#F5B301]" />
                          <span>Cinematic Runway Reel (Video)</span>
                        </button>
                      </div>
                    </div>

                    {/* Headline Inputs */}
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Hero Main Headline</label>
                      <input
                        type="text"
                        value={heroConfig.headline}
                        onChange={(e) => updateHeroConfig({ headline: e.target.value })}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-stone-900 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Badge Tagline</label>
                      <input
                        type="text"
                        value={heroConfig.badgeText}
                        onChange={(e) => updateHeroConfig({ badgeText: e.target.value })}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-stone-900"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-stone-700 font-medium mb-1">Hero Subheadline</label>
                      <textarea
                        rows={2}
                        value={heroConfig.subheadline}
                        onChange={(e) => updateHeroConfig({ subheadline: e.target.value })}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-stone-900"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-stone-700 font-medium mb-1">Promotional Banner Copy</label>
                      <input
                        type="text"
                        value={heroConfig.promoBannerText}
                        onChange={(e) => updateHeroConfig({ promoBannerText: e.target.value })}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-stone-900 font-semibold"
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                    <Check className="w-4 h-4 shrink-0" />
                    <span>Any adjustments saved here immediately render on the live homepage!</span>
                  </div>
                </div>
              )}

            </div>
          </>
        )}

      </div>

      {/* PRINTABLE BILL & DELIVERY SLIP MODAL */}
      {selectedOrderForBill && (
        <div className="fixed inset-0 z-60 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-8 shadow-2xl space-y-6 text-stone-900 print:p-0 print:shadow-none print:border-none print:w-full">
            
            {/* Action Bar (Hidden on actual print) */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-4 print:hidden">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Official Tax Invoice & Delivery Manifest
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-[#F5B301] hover:bg-[#E0A200] text-stone-950 font-bold text-xs uppercase rounded-lg flex items-center gap-2 shadow-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Document</span>
                </button>
                <button
                  onClick={() => setSelectedOrderForBill(null)}
                  className="p-2 text-stone-400 hover:text-stone-900"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Header with NIKKI WORLD Logo */}
            <div className="flex items-start justify-between border-b-2 border-stone-900 pb-6">
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-stone-900 border border-amber-600/40 shrink-0">
                  <img src={BRAND_LOGO_SRC} alt="Nikki World" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h1 className="text-2xl font-black font-display tracking-tight text-stone-950">
                    NIKKI WORLD
                  </h1>
                  <p className="text-[10px] text-stone-500 uppercase tracking-widest font-semibold">
                    Haute Cordwaining & Sartorial Atelier
                  </p>
                  <p className="text-[11px] text-stone-600 mt-1">
                    Nikki World Flagship Boutique, Sardarpura, Jodhpur, Rajasthan 342003, India
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs uppercase tracking-widest text-[#B3541E] font-bold block">
                  Delivery Manifest & Invoice
                </span>
                <span className="text-lg font-mono font-extrabold text-stone-950 block mt-1">
                  {selectedOrderForBill.id}
                </span>
                <span className="text-xs text-stone-500 block">
                  Date: {selectedOrderForBill.orderDate}
                </span>
              </div>
            </div>

            {/* Consignee & Shipping Destination */}
            <div className="grid grid-cols-2 gap-8 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-stone-400 block mb-1">
                  Billed & Consigned To:
                </span>
                <strong className="text-sm font-bold text-stone-950 block">
                  {selectedOrderForBill.customerName}
                </strong>
                <p className="text-stone-600 mt-0.5 leading-relaxed">
                  {selectedOrderForBill.shippingAddress}<br />
                  {selectedOrderForBill.city}, {selectedOrderForBill.state} {selectedOrderForBill.postalCode}<br />
                  {selectedOrderForBill.country}
                </p>
                <p className="text-stone-500 mt-1">
                  {selectedOrderForBill.customerPhone} · {selectedOrderForBill.customerEmail}
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-stone-400 block mb-1">
                  Logistics & Tracking:
                </span>
                <p className="text-stone-800">
                  <strong>Carrier:</strong> DHL Worldwide Express Air<br />
                  <strong>Waybill #:</strong> <span className="font-mono font-bold">{selectedOrderForBill.trackingNumber}</span><br />
                  <strong>Payment Terms:</strong> {selectedOrderForBill.paymentMethod.toUpperCase()} (VERIFIED)
                </p>
                {/* Simulated Barcode */}
                <div className="mt-2 inline-block p-1 bg-stone-100 rounded border border-stone-200">
                  <div className="h-6 w-36 bg-repeating-linear-stripes text-[8px] font-mono text-center flex items-center justify-center tracking-widest text-stone-700">
                    |||| | ||||| || ||||
                  </div>
                </div>
              </div>
            </div>

            {/* Itemized Table */}
            <div>
              <table className="w-full text-left text-xs border border-stone-200 divide-y divide-stone-200">
                <thead className="bg-stone-50 font-bold uppercase tracking-wider text-[10px] text-stone-600">
                  <tr>
                    <th className="p-2.5">Artisan Item & Specifications</th>
                    <th className="p-2.5 text-center">Qty</th>
                    <th className="p-2.5 text-right">Unit Price</th>
                    <th className="p-2.5 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 tabular-nums">
                  {selectedOrderForBill.items.map((item, i) => (
                    <tr key={i}>
                      <td className="p-2.5">
                        <strong className="text-stone-900 block">{item.productName}</strong>
                        <span className="text-[11px] text-stone-500">Size: {item.selectedSize} · Color: {item.selectedColor}</span>
                      </td>
                      <td className="p-2.5 text-center">{item.quantity}</td>
                      <td className="p-2.5 text-right">${item.price}</td>
                      <td className="p-2.5 text-right font-bold">${item.price * item.quantity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="flex justify-end text-xs">
              <div className="w-64 space-y-1.5 text-stone-600 pt-2 border-t border-stone-200">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums">${selectedOrderForBill.subtotal}</span>
                </div>
                {selectedOrderForBill.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount</span>
                    <span className="tabular-nums">-${selectedOrderForBill.discount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>DHL Express Shipping</span>
                  <span className="tabular-nums">{selectedOrderForBill.shippingFee === 0 ? 'COMPLIMENTARY' : `$${selectedOrderForBill.shippingFee}`}</span>
                </div>
                <div className="flex justify-between text-sm font-extrabold text-stone-950 pt-2 border-t border-stone-300">
                  <span>Total Amount Paid</span>
                  <span className="tabular-nums">${selectedOrderForBill.total}</span>
                </div>
              </div>
            </div>

            {/* Document Footer */}
            <div className="pt-6 border-t border-stone-200 text-center text-[10px] text-stone-400 space-y-1">
              <p>Thank you for commissioning handcrafted pieces with NIKKI WORLD.</p>
              <p>Certified Genuine Tuscan Leather · 30-Day Bespoke Returns & Size Exchange Guarantee</p>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
