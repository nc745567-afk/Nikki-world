import React from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { CartDrawer } from './components/CartDrawer';
import { QuickViewModal } from './components/QuickViewModal';
import { AuthModal } from './components/AuthModal';
import { CustomerAccountModal } from './components/CustomerAccountModal';
import { AdminPortalModal } from './components/AdminPortalModal';
import { Footer } from './components/Footer';

// Pages
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';

import { CheckCircle2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentPage, toastMessage } = useShop();

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'shop':
        return <ShopPage />;
      case 'product-details':
        return <ProductDetailsPage />;
      case 'cart':
        return <CartPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900 overflow-x-hidden">
      {/* Top Bar adhering to strict Top Bar contract */}
      <Navbar />

      {/* Main Viewport Content */}
      <main className="flex-1 pb-16 md:pb-0">
        {renderCurrentPage()}
      </main>

      {/* Brand Footer */}
      <Footer />

      {/* Sticky Mobile Bottom Navigation for thumb reachability */}
      <MobileBottomNav />

      {/* Global Interactive Slide-Out Cart Drawer */}
      <CartDrawer />

      {/* Quick View Product Modal */}
      <QuickViewModal />

      {/* Sign in with Google / Registration Modal */}
      <AuthModal />

      {/* Customer Patron Account & Returns Modal */}
      <CustomerAccountModal />

      {/* Owner / Executive Portal Modal */}
      <AdminPortalModal />

      {/* Floating Feedback Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-8 right-4 md:right-8 z-50 bg-stone-950 text-white px-4 py-3 rounded-xl shadow-2xl border border-stone-800 flex items-center gap-2.5 text-xs font-medium animate-in fade-in slide-in-from-bottom-3 duration-300">
          <CheckCircle2 className="w-4 h-4 text-[#F5B301] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <ShopProvider>
      <AppContent />
    </ShopProvider>
  );
}
