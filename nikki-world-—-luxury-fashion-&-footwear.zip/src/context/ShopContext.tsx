import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  CartItem,
  PageType,
  User,
  Order,
  ReturnRequest,
  StaffMember,
  DiscountCoupon,
  HeroConfig,
  CheckoutFormData
} from '../types';
import { PRODUCTS, HERO_EDITORIAL_SRC } from '../data/products';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged
} from '../lib/firebase';

interface ShopContextType {
  currentPage: PageType;
  selectedProductId: string | null;
  products: Product[];
  cart: CartItem[];
  wishlist: string[];
  isCartOpen: boolean;
  quickViewProduct: Product | null;
  appliedCoupon: string | null;
  discountPercent: number;
  toastMessage: string | null;
  
  // Auth state
  currentUser: User | null;
  isAuthModalOpen: boolean;
  isAccountModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  setIsAccountModalOpen: (open: boolean) => void;
  loginWithGoogle: () => void;
  registerUser: (name: string, email: string, phone: string) => void;
  loginUser: (email: string) => void;
  logoutUser: () => void;

  // Admin / Owner Portal state
  isAdminModalOpen: boolean;
  isOwnerAuthenticated: boolean;
  setIsAdminModalOpen: (open: boolean) => void;
  ownerLogin: (id: string, pass: string) => boolean;
  ownerLogout: () => void;

  // Catalog / Inventory management (Live Sync)
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;

  // Orders & Checkout
  orders: Order[];
  createOrder: (formData: CheckoutFormData) => Order;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;

  // Return Requests
  returnRequests: ReturnRequest[];
  requestReturn: (orderId: string, reason: string) => void;
  updateReturnStatus: (returnId: string, status: ReturnRequest['status'], adminNotes?: string) => void;

  // Staff Management
  staffList: StaffMember[];
  addStaff: (member: Omit<StaffMember, 'id' | 'joinedDate'>) => void;
  deleteStaff: (id: string) => void;
  updateStaffStatus: (id: string, status: StaffMember['status']) => void;

  // Discount Coupons
  coupons: DiscountCoupon[];
  addCoupon: (coupon: DiscountCoupon) => void;
  toggleCoupon: (code: string) => void;
  deleteCoupon: (code: string) => void;

  // Home Screen Configuration (Video / Image)
  heroConfig: HeroConfig;
  updateHeroConfig: (config: Partial<HeroConfig>) => void;

  // Navigation & Shopping functions
  navigateTo: (page: PageType, productId?: string) => void;
  addToCart: (product: Product, selectedSize: string, selectedColor: string, quantity?: number) => void;
  updateCartQuantity: (cartItemId: string, newQuantity: number) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  setIsCartOpen: (open: boolean) => void;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;
  showToast: (message: string) => void;
  cartSubtotal: number;
  discountAmount: number;
  shippingFee: number;
  cartTotal: number;
  cartItemCount: number;
  freeShippingThreshold: number;
  freeShippingRemaining: number;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>('nw-oxford-cognac');
  
  // Dynamic Live Products
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('nikki_products');
    return saved ? JSON.parse(saved) : PRODUCTS;
  });

  // User Authentication
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('nikki_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);

  // Admin / Owner Portal
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isOwnerAuthenticated, setIsOwnerAuthenticated] = useState(() => {
    return sessionStorage.getItem('nikki_owner_auth') === 'true';
  });

  // Cart & Wishlist
  const [cart, setCart] = useState<CartItem[]>(() => [
    {
      id: 'nw-oxford-cognac-US 9 / EU 42.5-Tuscan Cognac',
      product: PRODUCTS[0],
      selectedColor: 'Tuscan Cognac',
      selectedSize: 'US 9 / EU 42.5',
      quantity: 1,
      price: PRODUCTS[0].price
    }
  ]);
  const [wishlist, setWishlist] = useState<string[]>(['nw-monarch-fedora', 'nw-chelsea-suede']);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('NIKKISTYLE');
  const [discountPercent, setDiscountPercent] = useState<number>(20);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Orders (clean state, real customer orders saved)
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('nikki_orders');
    return saved ? JSON.parse(saved) : [];
  });

  // Return Requests (clean state, populated when customers submit returns)
  const [returnRequests, setReturnRequests] = useState<ReturnRequest[]>(() => {
    const saved = localStorage.getItem('nikki_returns');
    return saved ? JSON.parse(saved) : [];
  });

  // Staff Management (clean state)
  const [staffList, setStaffList] = useState<StaffMember[]>(() => {
    const saved = localStorage.getItem('nikki_staff');
    return saved ? JSON.parse(saved) : [
      {
        id: 'st-1',
        name: 'Nemichand',
        role: 'Master Cordwainer',
        email: 'owner@nikkiworld.com',
        phone: '+91 291 261 4432',
        boutique: 'Jodhpur Flagship (Sardarpura)',
        status: 'Shift Active',
        joinedDate: '2024-01-01'
      }
    ];
  });
  // Discount Coupons
  const [coupons, setCoupons] = useState<DiscountCoupon[]>([
    {
      code: 'NIKKISTYLE',
      discountPercent: 20,
      description: 'Seasonal 20% off all handcrafted footwear & fedoras',
      minSpend: 150,
      usageCount: 428,
      isActive: true,
      expiresOn: '2026-12-31'
    },
    {
      code: 'VIP10',
      discountPercent: 10,
      description: 'Nikki World VIP Circle 10% lifetime discount',
      minSpend: 100,
      usageCount: 184,
      isActive: true,
      expiresOn: '2027-01-01'
    },
    {
      code: 'FLORENCE30',
      discountPercent: 30,
      description: 'Exclusive Trunk Show patron savings',
      minSpend: 500,
      usageCount: 52,
      isActive: true,
      expiresOn: '2026-11-30'
    }
  ]);

  // Home Screen Configuration
  const [heroConfig, setHeroConfig] = useState<HeroConfig>({
    mediaType: 'image',
    mediaUrl: HERO_EDITORIAL_SRC,
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-in-autumn-clothes-walking-41440-large.mp4',
    badgeText: 'Autumn / Winter Luxury Atelier',
    headline: 'Discover Your Style.',
    subheadline: 'Hand-lasted Tuscan calfskin footwear, iconic wool felt fedoras, and bespoke Neapolitan tailoring crafted for the connoisseur of distinction.',
    promoBannerText: '20% Off All Handcrafted Footwear with code NIKKISTYLE'
  });

  const freeShippingThreshold = 250;

  // Persist products to localStorage
  useEffect(() => {
    localStorage.setItem('nikki_products', JSON.stringify(products));
  }, [products]);

  // Persist orders to localStorage
  useEffect(() => {
    localStorage.setItem('nikki_orders', JSON.stringify(orders));
  }, [orders]);

  // Persist returns to localStorage
  useEffect(() => {
    localStorage.setItem('nikki_returns', JSON.stringify(returnRequests));
  }, [returnRequests]);

  // Persist staff to localStorage
  useEffect(() => {
    localStorage.setItem('nikki_staff', JSON.stringify(staffList));
  }, [staffList]);

  // Persist user
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('nikki_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('nikki_user');
    }
  }, [currentUser]);

  // Synchronize with Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        const user: User = {
          id: fbUser.uid,
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Patron',
          email: fbUser.email || '',
          avatar: fbUser.photoURL || undefined,
          phone: fbUser.phoneNumber || undefined,
          authProvider: 'google',
          joinedDate: fbUser.metadata?.creationTime
            ? new Date(fbUser.metadata.creationTime).toISOString().split('T')[0]
            : new Date().toISOString().split('T')[0]
        };
        setCurrentUser(user);
      }
    });
    return () => unsubscribe();
  }, []);

  // Auto-clear toast
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const showToast = (message: string) => {
    setToastMessage(message);
  };

  const navigateTo = (page: PageType, productId?: string) => {
    setCurrentPage(page);
    if (productId) {
      setSelectedProductId(productId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Auth Handlers - Real Firebase Google Sign-In
  const loginWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const user: User = {
        id: fbUser.uid,
        name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Patron',
        email: fbUser.email || '',
        avatar: fbUser.photoURL || undefined,
        phone: fbUser.phoneNumber || undefined,
        authProvider: 'google',
        joinedDate: new Date().toISOString().split('T')[0]
      };
      setCurrentUser(user);
      setIsAuthModalOpen(false);
      showToast(`Welcome, ${user.name}! Signed in via Google.`);
    } catch (error: any) {
      console.warn('Firebase Google Sign-In error:', error);
      if (error?.code === 'auth/popup-closed-by-user') {
        showToast('Google sign-in was closed by user.');
      } else if (error?.code === 'auth/cancelled-popup-request') {
        // Ignored
      } else if (error?.code === 'auth/popup-blocked') {
        showToast('Browser blocked the Google popup. Please enable popups or sign in with email.');
      } else {
        showToast(error?.message || 'Unable to sign in with Google. Please try again.');
      }
    }
  };

  const registerUser = (name: string, email: string, phone: string) => {
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name,
      email,
      phone,
      authProvider: 'email',
      joinedDate: new Date().toISOString().split('T')[0]
    };
    setCurrentUser(newUser);
    setIsAuthModalOpen(false);
    showToast(`Welcome to Nikki World, ${name}!`);
  };

  const loginUser = (email: string) => {
    const existing: User = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email,
      authProvider: 'email',
      joinedDate: new Date().toISOString().split('T')[0]
    };
    setCurrentUser(existing);
    setIsAuthModalOpen(false);
    showToast(`Welcome back, ${existing.name}!`);
  };

  const logoutUser = async () => {
    try {
      await fbSignOut(auth);
    } catch (e) {
      console.warn('Firebase signout notification:', e);
    }
    setCurrentUser(null);
    showToast('You have been signed out.');
  };

  // Owner Portal Auth
  const ownerLogin = (id: string, pass: string): boolean => {
    if (id.trim() === 'Nemichand' && pass === 'Nemi@1234') {
      setIsOwnerAuthenticated(true);
      sessionStorage.setItem('nikki_owner_auth', 'true');
      showToast('Welcome, Master Nemichand. Owner Portal unlocked.');
      return true;
    }
    showToast('Invalid Owner credentials. Access denied.');
    return false;
  };

  const ownerLogout = () => {
    setIsOwnerAuthenticated(false);
    sessionStorage.removeItem('nikki_owner_auth');
    showToast('Owner Portal session terminated.');
  };

  // Inventory / Catalogue live sync
  const addProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`"${newProduct.name}" added to catalogue & synced with live web!`);
  };

  const updateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    showToast(`"${updated.name}" updated successfully.`);
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    showToast('Product removed from live catalogue.');
  };

  // Orders
  const createOrder = (formData: CheckoutFormData): Order => {
    const newOrder: Order = {
      id: `NW-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: currentUser?.id || 'guest',
      customerName: `${formData.firstName} ${formData.lastName}`,
      customerEmail: formData.email,
      customerPhone: formData.phone,
      shippingAddress: `${formData.address} ${formData.apartment ? `(${formData.apartment})` : ''}`,
      city: formData.city,
      state: formData.state,
      postalCode: formData.postalCode,
      country: formData.country,
      items: cart.map((c) => ({
        productId: c.product.id,
        productName: c.product.name,
        price: c.price,
        quantity: c.quantity,
        selectedSize: c.selectedSize,
        selectedColor: c.selectedColor,
        image: c.product.images[0]
      })),
      subtotal: cartSubtotal,
      discount: discountAmount,
      shippingFee: formData.deliveryOption === 'express' ? 25 : shippingFee,
      total: cartTotal + (formData.deliveryOption === 'express' ? 25 : 0),
      paymentMethod: formData.paymentMethod,
      status: 'Confirmed',
      trackingNumber: `DHL-EX-${Math.floor(100000000 + Math.random() * 900000000)}`,
      orderDate: new Date().toISOString().split('T')[0],
      deliveryDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      returnRequested: false,
      returnStatus: 'None'
    };

    setOrders((prev) => [newOrder, ...prev]);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    showToast(`Order ${orderId} updated to: ${status}`);
  };

  // Return Requests
  const requestReturn = (orderId: string, reason: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const newReturn: ReturnRequest = {
      id: `RET-${Math.floor(1000 + Math.random() * 9000)}`,
      orderId: order.id,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      productName: order.items.map((i) => i.productName).join(', '),
      reason,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'Pending'
    };

    setReturnRequests((prev) => [newReturn, ...prev]);
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, returnRequested: true, returnStatus: 'Pending', returnReason: reason }
          : o
      )
    );
    showToast('Return request submitted. Concierge will review within 24 hours.');
  };

  const updateReturnStatus = (returnId: string, status: ReturnRequest['status'], adminNotes?: string) => {
    const target = returnRequests.find((r) => r.id === returnId);
    if (!target) return;

    setReturnRequests((prev) =>
      prev.map((r) =>
        r.id === returnId ? { ...r, status, adminNotes: adminNotes || r.adminNotes } : r
      )
    );

    // Instant update on customer account
    setOrders((prev) =>
      prev.map((o) =>
        o.id === target.orderId
          ? { ...o, returnStatus: status }
          : o
      )
    );

    showToast(`Return request ${returnId} marked as: ${status}. Customer account updated.`);
  };

  // Staff
  const addStaff = (member: Omit<StaffMember, 'id' | 'joinedDate'>) => {
    const newStaff: StaffMember = {
      ...member,
      id: `st-${Date.now()}`,
      joinedDate: new Date().toISOString().split('T')[0]
    };
    setStaffList((prev) => [...prev, newStaff]);
    showToast(`Staff member "${member.name}" added successfully.`);
  };

  const deleteStaff = (id: string) => {
    setStaffList((prev) => prev.filter((s) => s.id !== id));
    showToast('Staff member removed.');
  };

  const updateStaffStatus = (id: string, status: StaffMember['status']) => {
    setStaffList((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
    showToast('Staff status updated.');
  };

  // Coupons
  const addCoupon = (coupon: DiscountCoupon) => {
    setCoupons((prev) => [coupon, ...prev]);
    showToast(`Coupon "${coupon.code}" created and active.`);
  };

  const toggleCoupon = (code: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.code === code ? { ...c, isActive: !c.isActive } : c))
    );
  };

  const deleteCoupon = (code: string) => {
    setCoupons((prev) => prev.filter((c) => c.code !== code));
    showToast(`Coupon "${code}" deleted.`);
  };

  // Hero Config
  const updateHeroConfig = (newConfig: Partial<HeroConfig>) => {
    setHeroConfig((prev) => ({ ...prev, ...newConfig }));
    showToast('Home Screen presentation updated live!');
  };

  // Cart operations
  const addToCart = (product: Product, selectedSize: string, selectedColor: string, quantity = 1) => {
    const cartItemId = `${product.id}-${selectedSize}-${selectedColor}`;
    
    setCart((prev) => {
      const existing = prev.find((item) => item.id === cartItemId);
      if (existing) {
        return prev.map((item) =>
          item.id === cartItemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          product,
          selectedSize,
          selectedColor,
          quantity,
          price: product.price
        }
      ];
    });

    showToast(`Added ${product.name} (${selectedSize}) to Bag`);
    setIsCartOpen(true);
  };

  const updateCartQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity: newQuantity } : item))
    );
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
    showToast('Item removed from shopping bag');
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    const isWished = wishlist.includes(productId);
    if (isWished) {
      setWishlist((prev) => prev.filter((id) => id !== productId));
      showToast('Removed from Wishlist');
    } else {
      setWishlist((prev) => [...prev, productId]);
      showToast('Saved to Wishlist');
    }
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const applyCoupon = (code: string): boolean => {
    const clean = code.trim().toUpperCase();
    const found = coupons.find((c) => c.code === clean && c.isActive);
    if (found) {
      setAppliedCoupon(found.code);
      setDiscountPercent(found.discountPercent);
      showToast(`Code ${found.code} applied! ${found.discountPercent}% savings unlocked.`);
      return true;
    }
    if (clean === 'NIKKISTYLE' || clean === 'NIKKI20') {
      setAppliedCoupon(clean);
      setDiscountPercent(20);
      showToast('Code NIKKISTYLE applied! 20% savings unlocked.');
      return true;
    }
    showToast('Invalid or expired promo code.');
    return false;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setDiscountPercent(0);
    showToast('Promotional coupon removed');
  };

  const openQuickView = (product: Product) => {
    setQuickViewProduct(product);
  };

  const closeQuickView = () => {
    setQuickViewProduct(null);
  };

  // Computations
  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartSubtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  const discountAmount = Math.round((cartSubtotal * discountPercent) / 100);
  const shippingFee = cartSubtotal >= freeShippingThreshold || cartSubtotal === 0 ? 0 : 25;
  const cartTotal = Math.max(0, cartSubtotal - discountAmount + shippingFee);
  const freeShippingRemaining = Math.max(0, freeShippingThreshold - cartSubtotal);

  return (
    <ShopContext.Provider
      value={{
        currentPage,
        selectedProductId,
        products,
        cart,
        wishlist,
        isCartOpen,
        quickViewProduct,
        appliedCoupon,
        discountPercent,
        toastMessage,

        // Auth
        currentUser,
        isAuthModalOpen,
        isAccountModalOpen,
        setIsAuthModalOpen,
        setIsAccountModalOpen,
        loginWithGoogle,
        registerUser,
        loginUser,
        logoutUser,

        // Owner Portal
        isAdminModalOpen,
        isOwnerAuthenticated,
        setIsAdminModalOpen,
        ownerLogin,
        ownerLogout,

        // Inventory
        addProduct,
        updateProduct,
        deleteProduct,

        // Orders
        orders,
        createOrder,
        updateOrderStatus,

        // Returns
        returnRequests,
        requestReturn,
        updateReturnStatus,

        // Staff
        staffList,
        addStaff,
        deleteStaff,
        updateStaffStatus,

        // Coupons
        coupons,
        addCoupon,
        toggleCoupon,
        deleteCoupon,

        // Hero Config
        heroConfig,
        updateHeroConfig,

        // Nav & Shopping
        navigateTo,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        toggleWishlist,
        isWishlisted,
        applyCoupon,
        removeCoupon,
        setIsCartOpen,
        openQuickView,
        closeQuickView,
        showToast,
        cartSubtotal,
        discountAmount,
        shippingFee,
        cartTotal,
        cartItemCount,
        freeShippingThreshold,
        freeShippingRemaining
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
