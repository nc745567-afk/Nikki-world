export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'Footwear' | 'Hats' | 'Tailoring' | 'Accessories' | 'Women' | string;
  gender: 'Men' | 'Women' | 'Unisex';
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  images: string[];
  colors: { name: string; hex: string; inStock: boolean }[];
  sizes: { size: string; stock: 'in_stock' | 'low_stock' | 'out_of_stock' }[];
  badge?: 'BESTSELLER' | 'NEW SEASON' | 'LIMITED RUN' | '20% OFF' | 'ARTISANAL' | string;
  isTrending?: boolean;
  isBestseller?: boolean;
  description: string;
  features: string[];
  specs: {
    craftsmanship: string;
    materials: string;
    fitRecommendation: string;
    shipping: string;
  };
  sku: string;
}

export interface CartItem {
  id: string; // Unique cart item ID (combines product id + size + color)
  product: Product;
  selectedColor: string;
  selectedSize: string;
  quantity: number;
  price: number;
}

export interface Review {
  id: string;
  author: string;
  verified: boolean;
  rating: number;
  date: string;
  title: string;
  comment: string;
  location: string;
}

export type PageType = 'home' | 'shop' | 'product-details' | 'cart' | 'checkout' | 'about' | 'contact';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  authProvider: 'google' | 'email';
  joinedDate: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  selectedSize: string;
  selectedColor: string;
  image: string;
}

export interface Order {
  id: string; // e.g. NW-2026-8842
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'card' | 'apple_pay' | 'cod';
  status: 'Pending' | 'Confirmed' | 'Dispatched' | 'In Transit' | 'Delivered' | 'Cancelled';
  trackingNumber: string;
  orderDate: string;
  deliveryDate: string;
  returnRequested?: boolean;
  returnStatus?: 'None' | 'Pending' | 'Approved' | 'Refunded' | 'Rejected';
  returnReason?: string;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  customerName: string;
  customerEmail: string;
  productName: string;
  reason: string;
  requestDate: string;
  status: 'Pending' | 'Approved' | 'Refunded' | 'Rejected';
  adminNotes?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: 'Master Cordwainer' | 'Inventory Lead' | 'Concierge Manager' | 'Boutique Stylist' | 'Logistics Lead';
  email: string;
  phone: string;
  boutique: string;
  status: 'Active' | 'On Leave' | 'Shift Active';
  joinedDate: string;
}

export interface DiscountCoupon {
  code: string;
  discountPercent: number;
  description: string;
  minSpend: number;
  usageCount: number;
  isActive: boolean;
  expiresOn: string;
}

export interface HeroConfig {
  mediaType: 'image' | 'video';
  mediaUrl: string;
  videoUrl?: string;
  badgeText: string;
  headline: string;
  subheadline: string;
  promoBannerText: string;
}

export interface CheckoutFormData {
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
  address: string;
  apartment: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  deliveryOption: 'standard' | 'express';
  paymentMethod: 'card' | 'apple_pay' | 'cod';
  cardNumber?: string;
  cardExpiry?: string;
  cardCvc?: string;
  saveInfo: boolean;
}
